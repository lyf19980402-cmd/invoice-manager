package com.example.invoicemanager

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    data class Invoice(
        val id: String,
        val name: String,
        val category: String,
        val isPdf: Boolean,
        val localPath: String?,
        val originalUri: String? = null
    )

    data class Project(
        val id: String,
        var name: String,
        val categories: MutableList<String> = mutableListOf("办公", "交通", "住宿", "餐饮", "设备", "其他"),
        val invoices: MutableList<Invoice> = mutableListOf()
    )

    private val projects = mutableListOf<Project>()
    private val selectedIds = linkedSetOf<String>()
    private var activeProjectId: String? = null
    private var pendingOutput: File? = null
    private val PICK_FILES = 1001

    private val pine = Color.rgb(25, 63, 53)
    private val pineLight = Color.rgb(230, 240, 235)
    private val page = Color.rgb(246, 247, 244)
    private val ink = Color.rgb(31, 43, 39)
    private val muted = Color.rgb(112, 124, 118)
    private val line = Color.rgb(224, 231, 226)
    private val white = Color.WHITE

    private lateinit var homeProjectList: LinearLayout
    private lateinit var projectNameInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var filterSpinner: Spinner
    private lateinit var invoiceListLayout: LinearLayout
    private lateinit var statusText: TextView
    private val statValues = mutableListOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pine
        window.navigationBarColor = page
        PDFBoxResourceLoader.init(applicationContext)
        loadState()
        buildHomeUi()
    }

    override fun onBackPressed() {
        if (activeProjectId != null) {
            activeProjectId = null
            selectedIds.clear()
            pendingOutput = null
            buildHomeUi()
        } else {
            super.onBackPressed()
        }
    }

    private fun currentProject(): Project? = projects.firstOrNull { it.id == activeProjectId }

    private fun buildHomeUi() {
        activeProjectId = null
        statValues.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(23), dp(25), dp(23), dp(24))
            background = rounded(pine, 0)
        }
        header.addView(text("发票小管家", 29f, white, true))
        header.addView(text("项目清晰，发票不乱", 14f, Color.rgb(213, 229, 219)).apply {
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(header, matchWrap())

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(17), dp(18), dp(17), dp(26))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(12))
        }
        titleRow.addView(text("我的项目", 23f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(text("${projects.size} 个项目", 12f, pine, true).apply {
            background = rounded(pineLight, 30)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        })
        body.addView(titleRow)

        homeProjectList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(homeProjectList, matchWrap())

        val createCard = cardContainer().apply { setPadding(dp(17), dp(18), dp(17), dp(18)) }
        createCard.addView(text("新建项目", 19f, ink, true))
        createCard.addView(text("每个项目的发票、分类和合并操作互相独立。", 13f, muted).apply {
            setPadding(0, dp(6), 0, dp(12))
        })
        projectNameInput = EditText(this).apply {
            hint = "例如：2026年纪录片项目"
            textSize = 15f
            isSingleLine = true
            setTextColor(ink)
            setHintTextColor(Color.rgb(155, 164, 158))
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = rounded(white, 14, line, 1)
        }
        createCard.addView(projectNameInput, LinearLayout.LayoutParams(-1, dp(52)))
        createCard.addView(actionButton("＋  创建项目", pine, white) { createProject() }, LinearLayout.LayoutParams(-1, dp(49)).apply {
            topMargin = dp(12)
        })
        body.addView(createCard, matchWrap().apply { topMargin = dp(18) })
        body.addView(text("数据仅保存在这台手机的应用空间内。删除项目时，只删除应用保存的副本，不会删除相册或下载目录里的原文件。", 12f, muted).apply {
            setPadding(dp(5), dp(13), dp(5), 0)
        })
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHomeProjects()
    }

    private fun refreshHomeProjects() {
        if (!::homeProjectList.isInitialized) return
        homeProjectList.removeAllViews()
        if (projects.isEmpty()) {
            val empty = cardContainer().apply { setPadding(dp(18), dp(19), dp(18), dp(19)) }
            empty.addView(text("还没有项目", 17f, ink, true))
            empty.addView(text("先创建一个项目，再把对应发票导入其中。", 13f, muted).apply { setPadding(0, dp(5), 0, 0) })
            homeProjectList.addView(empty, matchWrap())
            return
        }
        projects.forEachIndexed { index, project ->
            val outer = cardContainer().apply {
                setPadding(dp(13), dp(13), dp(8), dp(13))
                isClickable = true
                setOnClickListener { openProject(project.id) }
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val folder = TextView(this).apply {
                text = "▤"
                textSize = 26f
                gravity = Gravity.CENTER
                setTextColor(pine)
                background = rounded(pineLight, 15)
            }
            row.addView(folder, LinearLayout.LayoutParams(dp(52), dp(52)))
            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(13), 0, dp(7), 0)
            }
            details.addView(text(project.name, 17f, ink, true))
            details.addView(text("${project.categories.size} 个分类  ·  ${project.invoices.size} 张发票", 12.5f, muted).apply {
                setPadding(0, dp(5), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("›", 30f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(27), dp(48)))
            outer.addView(row)
            // A separate menu button preserves the simple tap-to-open card interaction.
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            actions.addView(actionButton("项目管理  ⋯", pineLight, pine, 12f) { showProjectActions(project) }, LinearLayout.LayoutParams(-2, dp(35)))
            outer.addView(actions, matchWrap().apply { topMargin = dp(7) })
            homeProjectList.addView(outer, matchWrap().apply { bottomMargin = dp(11) })
        }
    }

    private fun createProject() {
        val name = projectNameInput.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "先给项目起个名字", Toast.LENGTH_SHORT).show()
            return
        }
        if (projects.any { it.name.equals(name, ignoreCase = true) }) {
            Toast.makeText(this, "已经有同名项目了，请换个名称", Toast.LENGTH_SHORT).show()
            return
        }
        val project = Project(UUID.randomUUID().toString(), name)
        projects.add(project)
        persistState()
        openProject(project.id)
    }

    private fun showProjectActions(project: Project) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(project.name)
            .setItems(arrayOf("重命名项目", "删除整个项目")) { _, which ->
                if (which == 0) renameProject(project) else confirmDeleteProject(project)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun renameProject(project: Project) {
        val input = EditText(this).apply {
            setText(project.name)
            setSelection(text.length)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("重命名项目")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    project.name = name
                    persistState()
                    if (activeProjectId == project.id) buildDetailUi() else buildHomeUi()
                }
            }
            .show()
    }

    private fun confirmDeleteProject(project: Project) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("删除整个项目？")
            .setMessage("将删除“${project.name}”以及发票小管家保存的文件副本和记录。不会删除手机相册、下载目录里的原始文件。此操作无法撤销。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除项目") { _, _ ->
                deleteRecursively(File(filesDir, "projectFiles/${project.id}"))
                projects.removeAll { it.id == project.id }
                if (activeProjectId == project.id) activeProjectId = null
                selectedIds.clear()
                pendingOutput = null
                persistState()
                buildHomeUi()
            }
            .show()
    }

    private fun openProject(id: String) {
        if (projects.none { it.id == id }) return
        activeProjectId = id
        selectedIds.clear()
        pendingOutput = null
        buildDetailUi()
    }

    private fun buildDetailUi() {
        val project = currentProject() ?: run { buildHomeUi(); return }
        statValues.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(16), dp(14), dp(17))
            background = rounded(pine, 0)
        }
        header.addView(actionButton("‹", pine, white, 29f) {
            activeProjectId = null
            selectedIds.clear()
            pendingOutput = null
            buildHomeUi()
        }, LinearLayout.LayoutParams(dp(42), dp(46)))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, dp(7), 0)
        }
        heading.addView(text(project.name, 20f, white, true, maxLines = 1))
        heading.addView(text("项目发票 · 分类归档", 12f, Color.rgb(211, 227, 217)).apply { setPadding(0, dp(3), 0, 0) })
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionButton("⋯", pine, white, 23f) { showProjectActions(project) }, LinearLayout.LayoutParams(dp(40), dp(44)))
        root.addView(header, matchWrap())

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(14), dp(14), dp(14), dp(15))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val overview = cardContainer().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        overview.addView(text("发票概览", 18f, ink, true))
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        listOf("全部文件", "图片", "PDF", "已选择").forEachIndexed { idx, label ->
            val stat = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(9), dp(5), dp(9))
                background = rounded(pineLight, 13)
            }
            val value = text("0", 22f, ink, true)
            statValues.add(value)
            stat.addView(value)
            stat.addView(text(label, 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
            statsRow.addView(stat, LinearLayout.LayoutParams(0, dp(76), 1f).apply {
                if (idx > 0) leftMargin = dp(6)
            })
        }
        overview.addView(statsRow)
        body.addView(overview, matchWrap().apply { bottomMargin = dp(13) })

        val importCard = cardContainer().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        importCard.addView(text("①  导入发票", 18f, ink, true))
        importCard.addView(text("选择新导入发票所属的分类", 12f, muted).apply { setPadding(0, dp(9), 0, dp(5)) })
        val categoryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        categorySpinner = Spinner(this)
        updateCategorySpinner()
        categoryRow.addView(categorySpinner, LinearLayout.LayoutParams(0, dp(48), 1f))
        categoryRow.addView(actionButton("＋ 新分类", pineLight, pine, 13f) { addCategoryDialog() }, LinearLayout.LayoutParams(-2, dp(47)).apply { leftMargin = dp(8) })
        importCard.addView(categoryRow)
        importCard.addView(actionButton("＋ 选择图片 / PDF", pine, white, 15f) { pickFiles() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        importCard.addView(text("图片和 PDF 会复制保存到本项目。删除项目只会删除应用里的副本，不会动原文件。", 12f, muted).apply {
            setPadding(0, dp(9), 0, 0)
        })
        body.addView(importCard, matchWrap().apply { bottomMargin = dp(13) })

        val listCard = cardContainer().apply { setPadding(dp(16), dp(15), dp(16), dp(10)) }
        val listHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listHeading.addView(text("②  分类查看", 18f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        listCard.addView(listHeading)
        filterSpinner = Spinner(this)
        updateFilterSpinner()
        listCard.addView(filterSpinner, matchWrap().apply { topMargin = dp(7); bottomMargin = dp(7) })
        val selectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        selectRow.addView(actionButton("全选当前分类", pineLight, pine, 12f) { selectCurrentVisible() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        selectRow.addView(actionButton("取消选择", pineLight, pine, 12f) {
            selectedIds.clear(); refreshInvoiceList()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        listCard.addView(selectRow)
        invoiceListLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.addView(invoiceListLayout, matchWrap().apply { topMargin = dp(9) })
        body.addView(listCard, matchWrap())
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(12))
            background = rounded(white, 17, line, 1)
        }
        statusText = text("发票只保存在当前项目中。", 12f, muted).apply {
            setPadding(dp(2), 0, dp(2), dp(6))
        }
        footer.addView(statusText)
        footer.addView(actionButton("一键合并所选为 PDF", pine, white, 15f) { mergeSelected() }, LinearLayout.LayoutParams(-1, dp(47)))
        footer.addView(actionButton("分享 / 发送生成的 PDF", pineLight, pine, 14f) { shareLast() }, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(7) })
        root.addView(footer, matchWrap())

        setContentView(root)
        filterSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshInvoiceList() }
        }
        refreshInvoiceList()
    }

    private fun updateCategorySpinner() {
        val project = currentProject() ?: return
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, project.categories).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun updateFilterSpinner() {
        val project = currentProject() ?: return
        filterSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("全部") + project.categories).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun addCategoryDialog() {
        val project = currentProject() ?: return
        val input = EditText(this).apply {
            hint = "例如：差旅、采购、后期制作"
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("在“${project.name}”中新建分类")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("添加") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                if (project.categories.contains(name)) {
                    Toast.makeText(this, "这个分类已经存在", Toast.LENGTH_SHORT).show()
                } else {
                    project.categories.add(name)
                    persistState()
                    updateCategorySpinner()
                    updateFilterSpinner()
                    refreshInvoiceList()
                }
            }
            .show()
    }

    private fun pickFiles() {
        if (currentProject() == null) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_FILES)
    }

    @Deprecated("legacy callback for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FILES || resultCode != Activity.RESULT_OK || data == null) return
        val project = currentProject() ?: return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        val category = if (::categorySpinner.isInitialized) categorySpinner.selectedItem?.toString() ?: "其他" else "其他"
        var imported = 0
        var failed = 0
        uris.forEach { uri ->
            try {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = queryName(uri) ?: "发票_${project.invoices.size + 1}"
                val mime = contentResolver.getType(uri) ?: ""
                val isPdf = mime.equals("application/pdf", true) || name.lowercase(Locale.ROOT).endsWith(".pdf")
                val isImage = mime.startsWith("image/") || name.lowercase(Locale.ROOT).let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") || it.endsWith(".heic") }
                if (!isPdf && !isImage) throw IllegalArgumentException("只支持图片和 PDF")
                val copy = copyUriIntoProject(uri, project, name, isPdf)
                project.invoices.add(Invoice(UUID.randomUUID().toString(), name, category, isPdf, copy.absolutePath, uri.toString()))
                imported++
            } catch (_: Exception) { failed++ }
        }
        persistState()
        refreshInvoiceList()
        statusText.text = if (failed == 0) "已导入 $imported 个文件到“${project.name}”。" else "成功导入 $imported 个，失败 $failed 个；请检查文件格式或读取权限。"
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun copyUriIntoProject(uri: Uri, project: Project, displayName: String, isPdf: Boolean): File {
        val directory = File(filesDir, "projectFiles/${project.id}").apply { mkdirs() }
        var ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext.length !in 2..6 || ext.any { !it.isLetterOrDigit() }) ext = if (isPdf) "pdf" else "jpg"
        val file = File(directory, "${UUID.randomUUID()}.$ext")
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法读取文件")
        input.use { source -> FileOutputStream(file).use { target -> source.copyTo(target) } }
        return file
    }

    private fun refreshInvoiceList() {
        if (!::invoiceListLayout.isInitialized) return
        val project = currentProject() ?: return
        invoiceListLayout.removeAllViews()
        val filter = if (::filterSpinner.isInitialized) filterSpinner.selectedItem?.toString() ?: "全部" else "全部"
        val visible = project.invoices.filter { filter == "全部" || it.category == filter }
        if (visible.isEmpty()) {
            invoiceListLayout.addView(text("当前分类暂无发票。\n点击上方“选择图片 / PDF”导入文件。", 13f, muted).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(24), dp(8), dp(24))
            })
        } else {
            visible.forEach { inv ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(2), dp(9), dp(1), dp(9))
                }
                val check = CheckBox(this).apply {
                    buttonTintList = ColorStateList.valueOf(pine)
                    isChecked = selectedIds.contains(inv.id)
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedIds.add(inv.id) else selectedIds.remove(inv.id)
                        refreshStats()
                    }
                }
                row.addView(check, LinearLayout.LayoutParams(dp(39), dp(43)))
                val detail = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(5), 0, dp(4), 0)
                }
                detail.addView(text(inv.name, 13f, ink, true, maxLines = 2))
                detail.addView(text("${inv.category}  ·  ${if (inv.isPdf) "PDF 文件" else "图片"}", 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
                row.addView(detail, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actionButton("删除", Color.rgb(247, 239, 235), Color.rgb(140, 70, 56), 12f) {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("删除这张发票？")
                        .setMessage("只会删除发票小管家内保存的副本，不会删除原始文件。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除") { _, _ ->
                            inv.localPath?.let { File(it).delete() }
                            project.invoices.removeAll { it.id == inv.id }
                            selectedIds.remove(inv.id)
                            persistState()
                            refreshInvoiceList()
                        }
                        .show()
                }, LinearLayout.LayoutParams(dp(58), dp(38)))
                invoiceListLayout.addView(row)
                invoiceListLayout.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        refreshStats()
    }

    private fun refreshStats() {
        val project = currentProject() ?: return
        if (statValues.size >= 4) {
            statValues[0].text = project.invoices.size.toString()
            statValues[1].text = project.invoices.count { !it.isPdf }.toString()
            statValues[2].text = project.invoices.count { it.isPdf }.toString()
            statValues[3].text = selectedIds.intersect(project.invoices.map { it.id }.toSet()).size.toString()
        }
    }

    private fun selectCurrentVisible() {
        val project = currentProject() ?: return
        val filter = filterSpinner.selectedItem?.toString() ?: "全部"
        project.invoices.filter { filter == "全部" || it.category == filter }.forEach { selectedIds.add(it.id) }
        refreshInvoiceList()
    }

    private fun mergeSelected() {
        val project = currentProject() ?: return
        val chosen = project.invoices.filter { selectedIds.contains(it.id) }
        if (chosen.isEmpty()) {
            statusText.text = "请先勾选要合并的发票。"
            return
        }
        statusText.text = "正在合并 ${chosen.size} 个文件，请稍候……"
        Thread {
            try {
                val merger = PDFMergerUtility()
                val tempDir = File(cacheDir, "invoice_merge").apply { mkdirs() }
                val temps = mutableListOf<File>()
                chosen.forEachIndexed { index, invoice ->
                    val temp = File(tempDir, "part_${index}_${UUID.randomUUID()}.pdf")
                    openInvoiceStream(invoice).use { input ->
                        if (invoice.isPdf) {
                            FileOutputStream(temp).use { output -> input.copyTo(output) }
                        } else {
                            val bitmap = BitmapFactory.decodeStream(input) ?: throw IllegalStateException("无法读取图片：${invoice.name}")
                            val doc = PdfDocument()
                            val info = PdfDocument.PageInfo.Builder(bitmap.width.coerceAtLeast(1), bitmap.height.coerceAtLeast(1), 1).create()
                            val page = doc.startPage(info)
                            page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                            doc.finishPage(page)
                            FileOutputStream(temp).use { output -> doc.writeTo(output) }
                            doc.close()
                            bitmap.recycle()
                        }
                    }
                    temps.add(temp)
                }
                val safeName = project.name.replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(30).ifBlank { "项目" }
                val outputDir = getExternalFilesDir(null) ?: filesDir
                val output = File(outputDir, "${safeName}_发票合并_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.CHINA).format(Date())}.pdf")
                merger.destinationFileName = output.absolutePath
                temps.forEach { merger.addSource(it) }
                merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly())
                temps.forEach { it.delete() }
                runOnUiThread {
                    pendingOutput = output
                    statusText.text = "合并完成：${chosen.size} 个文件。点击下方分享按钮发送到微信等应用。"
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "合并失败：${e.message ?: "请检查文件是否损坏或加密"}" }
            }
        }.start()
    }

    private fun openInvoiceStream(invoice: Invoice): InputStream {
        val local = invoice.localPath?.let { File(it) }
        if (local != null && local.exists()) return FileInputStream(local)
        val original = invoice.originalUri ?: throw IllegalStateException("找不到文件副本：${invoice.name}")
        return contentResolver.openInputStream(Uri.parse(original)) ?: throw IllegalStateException("无法读取文件：${invoice.name}")
    }

    private fun shareLast() {
        val file = pendingOutput
        if (file == null || !file.exists()) {
            statusText.text = "请先合并发票，再分享生成的 PDF。"
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "发送合并后的发票 PDF"))
        } catch (e: Exception) {
            statusText.text = "打开分享菜单失败：${e.message ?: "请稍后重试"}"
        }
    }

    private fun persistState() {
        try {
            val array = JSONArray()
            projects.forEach { project ->
                val categoryArray = JSONArray()
                project.categories.forEach { categoryArray.put(it) }
                val invoicesArray = JSONArray()
                project.invoices.forEach { invoice ->
                    invoicesArray.put(JSONObject()
                        .put("id", invoice.id)
                        .put("name", invoice.name)
                        .put("category", invoice.category)
                        .put("isPdf", invoice.isPdf)
                        .put("localPath", invoice.localPath)
                        .put("originalUri", invoice.originalUri))
                }
                array.put(JSONObject()
                    .put("id", project.id)
                    .put("name", project.name)
                    .put("categories", categoryArray)
                    .put("invoices", invoicesArray))
            }
            getSharedPreferences("invoice_manager", MODE_PRIVATE).edit().putString("projects_v2", array.toString()).apply()
        } catch (_: Exception) {
            Toast.makeText(this, "保存项目记录失败，请稍后重试", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadState() {
        val prefs = getSharedPreferences("invoice_manager", MODE_PRIVATE)
        try {
            val raw = prefs.getString("projects_v2", null)
            if (!raw.isNullOrBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val categoryList = mutableListOf<String>()
                    val ca = obj.optJSONArray("categories") ?: JSONArray()
                    for (c in 0 until ca.length()) categoryList.add(ca.getString(c))
                    if (categoryList.isEmpty()) categoryList.addAll(defaultCategories())
                    val project = Project(obj.getString("id"), obj.getString("name"), categoryList)
                    val invoicesArray = obj.optJSONArray("invoices") ?: JSONArray()
                    for (j in 0 until invoicesArray.length()) {
                        val invoice = invoicesArray.getJSONObject(j)
                        project.invoices.add(Invoice(
                            invoice.optString("id", UUID.randomUUID().toString()),
                            invoice.getString("name"),
                            invoice.optString("category", "其他"),
                            invoice.optBoolean("isPdf", false),
                            invoice.optString("localPath").takeIf { it.isNotBlank() && it != "null" },
                            invoice.optString("originalUri").takeIf { it.isNotBlank() && it != "null" }
                        ))
                    }
                    projects.add(project)
                }
            } else {
                migrateLegacyState(prefs)
            }
        } catch (_: Exception) {
            projects.clear()
            migrateLegacyState(prefs)
        }
    }

    private fun migrateLegacyState(prefs: android.content.SharedPreferences) {
        try {
            val oldInvoices = prefs.getString("invoices", null) ?: return
            val array = JSONArray(oldInvoices)
            if (array.length() == 0) return
            val categories = mutableListOf<String>()
            prefs.getString("categories", null)?.let { raw ->
                val categoryArray = JSONArray(raw)
                for (i in 0 until categoryArray.length()) categories.add(categoryArray.getString(i))
            }
            if (categories.isEmpty()) categories.addAll(defaultCategories())
            val project = Project(UUID.randomUUID().toString(), "默认项目", categories)
            for (i in 0 until array.length()) {
                val old = array.getJSONObject(i)
                val uriString = old.optString("uri")
                val name = old.optString("name", "发票_${i + 1}")
                val uri = Uri.parse(uriString)
                val isPdf = old.optBoolean("isPdf", name.lowercase(Locale.ROOT).endsWith(".pdf"))
                val copy = try { copyUriIntoProject(uri, project, name, isPdf) } catch (_: Exception) { null }
                project.invoices.add(Invoice(UUID.randomUUID().toString(), name, old.optString("category", "其他"), isPdf, copy?.absolutePath, uriString))
            }
            projects.add(project)
            persistState()
        } catch (_: Exception) { }
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteRecursively(it) }
        file.delete()
    }

    private fun cardContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(white, 20, Color.rgb(239, 242, 238), 1)
    }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false,
        maxLines: Int = Int.MAX_VALUE
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        this.maxLines = maxLines
        if (maxLines < Int.MAX_VALUE) ellipsize = android.text.TextUtils.TruncateAt.END
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun actionButton(
        title: String,
        backgroundColor: Int,
        textColor: Int,
        textSize: Float = 14f,
        action: () -> Unit
    ): Button = Button(this).apply {
        text = title
        this.textSize = textSize
        isAllCaps = false
        setTextColor(textColor)
        background = rounded(backgroundColor, 14)
        stateListAnimator = null
        setPadding(dp(10), dp(5), dp(10), dp(5))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int = color, strokeWidth: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (strokeWidth > 0) setStroke(dp(strokeWidth), strokeColor)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private fun defaultCategories() = mutableListOf("办公", "交通", "住宿", "餐饮", "设备", "其他")
    }
}

package com.example.invoicemanager

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    data class Invoice(val uri: Uri, val name: String, val category: String, val isPdf: Boolean)
    private val invoices = mutableListOf<Invoice>()
    private val selected = mutableSetOf<Int>()
    private val categories = mutableListOf("办公", "交通", "住宿", "餐饮", "设备", "其他")
    private lateinit var categorySpinner: Spinner
    private lateinit var filterSpinner: Spinner
    private lateinit var listLayout: LinearLayout
    private lateinit var status: TextView
    private var pendingOutput: File? = null
    private val PICK_FILES = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        loadState()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18); setBackgroundColor(0xFFF4F6FB.toInt()) }
        root.addView(TextView(this).apply { text = "发票小管家"; textSize = 25f; setTextColor(0xFF2457D6.toInt()) })
        root.addView(TextView(this).apply { text = "个人版 · 分类归档 · 图片/PDF导入 · 合并分享"; textSize = 13f; setPadding(0, 0, 0, 12) })
        root.addView(button("＋ 导入图片 / PDF") { pickFiles() }, matchWrap())
        root.addView(TextView(this).apply { text = "新导入文件的分类："; setPadding(0, 8, 0, 3) })
        categorySpinner = Spinner(this); updateCategorySpinner(); root.addView(categorySpinner, matchWrap())
        root.addView(button("新建分类") { addCategoryDialog() }, matchWrap())
        root.addView(TextView(this).apply { text = "发票列表（勾选后合并）"; textSize = 18f; setPadding(0, 10, 0, 5) })
        filterSpinner = Spinner(this); updateFilterSpinner()
        filterSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refreshList() }
        }
        root.addView(filterSpinner, matchWrap())
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(button("全选当前分类") { val f = filterSpinner.selectedItem?.toString() ?: "全部"; invoices.forEachIndexed { i, v -> if (f == "全部" || v.category == f) selected.add(i) }; refreshList() }, LinearLayout.LayoutParams(0, -2, 1f))
        actionRow.addView(button("取消选择") { selected.clear(); refreshList() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actionRow)
        listLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(listLayout) }, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { text = "提示：请先导入发票。初版尚未实现重启后自动保存列表。"; textSize = 12f; setPadding(0, 8, 0, 8) }
        root.addView(status)
        root.addView(button("一键合并所选为 PDF") { mergeSelected() }, matchWrap())
        root.addView(button("分享 / 发送上次生成的 PDF") { shareLast() }, matchWrap())
        setContentView(root); refreshList()
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 }
    private fun button(t: String, action: () -> Unit) = Button(this).apply { text = t; setOnClickListener { action() } }
    private fun updateCategorySpinner() { if (::categorySpinner.isInitialized) categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories) }
    private fun updateFilterSpinner() { if (::filterSpinner.isInitialized) filterSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("全部") + categories) }
    private fun addCategoryDialog() {
        val input = EditText(this).apply { hint = "例如：差旅、采购" }
        android.app.AlertDialog.Builder(this).setTitle("新建分类").setView(input).setNegativeButton("取消", null).setPositiveButton("添加") { _, _ ->
            val name = input.text.toString().trim(); if (name.isNotEmpty() && !categories.contains(name)) { categories.add(name); persistState(); updateCategorySpinner(); updateFilterSpinner() }
        }.show()
    }
    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf")); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        startActivityForResult(intent, PICK_FILES)
    }
    @Deprecated("legacy callback for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FILES || resultCode != Activity.RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>(); data.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }; if (uris.isEmpty()) data.data?.let { uris.add(it) }
        val category = categorySpinner.selectedItem?.toString() ?: "其他"
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = queryName(uri) ?: "发票_${invoices.size + 1}"; val mime = contentResolver.getType(uri) ?: ""
            invoices.add(Invoice(uri, name, category, mime == "application/pdf" || name.lowercase().endsWith(".pdf")))
        }
        persistState(); refreshList(); status.text = "已导入 ${uris.size} 个文件。勾选后即可合并。"
    }
    private fun queryName(uri: Uri): String? = try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } } catch (_: Exception) { null }
    private fun refreshList() {
        if (!::listLayout.isInitialized) return
        listLayout.removeAllViews(); val f = if (::filterSpinner.isInitialized) filterSpinner.selectedItem?.toString() ?: "全部" else "全部"
        val visible = invoices.indices.filter { f == "全部" || invoices[it].category == f }
        if (visible.isEmpty()) { listLayout.addView(TextView(this).apply { text = "暂无发票，请点击上方导入。"; setPadding(0, 18, 0, 18) }); return }
        visible.forEach { index -> val inv = invoices[index]; val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 5, 0, 5) }
            row.addView(CheckBox(this).apply { isChecked = selected.contains(index); setOnCheckedChangeListener { _, yes -> if (yes) selected.add(index) else selected.remove(index) } })
            row.addView(TextView(this).apply { text = "${inv.name}\n${inv.category} · ${if (inv.isPdf) "PDF" else "图片"}"; textSize = 13f; setPadding(5, 0, 5, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("删除") { invoices.removeAt(index); selected.clear(); persistState(); refreshList() }); listLayout.addView(row); listLayout.addView(View(this).apply { setBackgroundColor(0xFFE1E6F0.toInt()) }, LinearLayout.LayoutParams(-1, 1))
        }
    }
    private fun mergeSelected() {
        if (selected.isEmpty()) { status.text = "请先勾选要合并的发票。"; return }
        status.text = "正在合并，请稍候……"
        val chosen = selected.sorted().mapNotNull { invoices.getOrNull(it) }
        Thread {
            try {
                val merger = PDFMergerUtility(); val tempDir = File(cacheDir, "invoice_merge").apply { mkdirs() }; val temps = mutableListOf<File>()
                chosen.forEachIndexed { n, inv -> val temp = File(tempDir, "part_$n.pdf")
                    contentResolver.openInputStream(inv.uri).use { input ->
                        if (inv.isPdf) temp.outputStream().use { out -> input!!.copyTo(out) }
                        else { val bitmap = BitmapFactory.decodeStream(input) ?: throw Exception("无法读取图片：${inv.name}"); val doc = PdfDocument(); val info = PdfDocument.PageInfo.Builder(bitmap.width.coerceAtLeast(1), bitmap.height.coerceAtLeast(1), 1).create(); val page = doc.startPage(info); page.canvas.drawBitmap(bitmap, 0f, 0f, null); doc.finishPage(page); temp.outputStream().use { doc.writeTo(it) }; doc.close(); bitmap.recycle() }
                    }; temps.add(temp)
                }
                val output = File(getExternalFilesDir(null), "发票合并_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.CHINA).format(Date())}.pdf")
                merger.destinationFileName = output.absolutePath; temps.forEach { merger.addSource(it) }; merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly())
                runOnUiThread { pendingOutput = output; status.text = "合并完成：${chosen.size} 个文件。点击下方分享按钮发送到微信。" }
            } catch (e: Exception) { runOnUiThread { status.text = "合并失败：${e.message ?: "请检查文件是否损坏或加密"}" } }
        }.start()
    }

    private fun persistState() {
        try {
            val prefs = getSharedPreferences("invoice_manager", MODE_PRIVATE)
            val categoryArray = JSONArray(); categories.forEach { categoryArray.put(it) }
            val invoiceArray = JSONArray()
            invoices.forEach { inv ->
                invoiceArray.put(JSONObject().put("uri", inv.uri.toString()).put("name", inv.name).put("category", inv.category).put("isPdf", inv.isPdf))
            }
            prefs.edit().putString("categories", categoryArray.toString()).putString("invoices", invoiceArray.toString()).apply()
        } catch (_: Exception) { status.text = "保存列表失败，请重新打开应用后检查文件。" }
    }

    private fun loadState() {
        try {
            val prefs = getSharedPreferences("invoice_manager", MODE_PRIVATE)
            prefs.getString("categories", null)?.let { raw ->
                val arr = JSONArray(raw); categories.clear()
                for (i in 0 until arr.length()) categories.add(arr.getString(i))
                if (categories.isEmpty()) categories.addAll(listOf("办公", "交通", "住宿", "餐饮", "设备", "其他"))
            }
            prefs.getString("invoices", null)?.let { raw ->
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    invoices.add(Invoice(Uri.parse(obj.getString("uri")), obj.getString("name"), obj.getString("category"), obj.getBoolean("isPdf")))
                }
            }
        } catch (_: Exception) { invoices.clear() }
    }

    private fun shareLast() {
        val file = pendingOutput
        if (file == null || !file.exists()) { status.text = "请先合并发票。"; return }
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "发送合并后的发票 PDF"))
    }
}

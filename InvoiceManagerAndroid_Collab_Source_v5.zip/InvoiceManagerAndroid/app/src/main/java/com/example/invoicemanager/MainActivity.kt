package com.example.invoicemanager

import android.app.Activity
import android.content.Intent
import android.content.ClipData
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    data class Invoice(
        val id: String,
        val name: String,
        val category: String,
        val isPdf: Boolean,
        val localPath: String?,
        val originalUri: String? = null,
        var note: String = ""
    )

    data class ExpenseItem(
        val id: String,
        var date: String,
        var description: String,
        var amount: Double,
        var hasInvoice: Boolean
    )

    data class PaymentPerson(
        val id: String,
        var name: String,
        var paid: Boolean = false,
        val expenses: MutableList<ExpenseItem> = mutableListOf()
    )

    data class UninvoicedRecord(
        val id: String,
        var date: String,
        var description: String,
        var amount: Double
    )

    data class Project(
        val id: String,
        var name: String,
        val categories: MutableList<String> = mutableListOf("办公", "交通", "住宿", "餐饮", "设备", "其他"),
        val invoices: MutableList<Invoice> = mutableListOf(),
        val paymentPeople: MutableList<PaymentPerson> = mutableListOf(),
        val uninvoicedRecords: MutableList<UninvoicedRecord> = mutableListOf()
    )

    private data class PackageInvoice(
        val name: String,
        val category: String,
        val isPdf: Boolean,
        val note: String,
        val archivePath: String
    )

    private data class ProjectSharePackage(
        val projectName: String,
        val categories: List<String>,
        val invoices: List<PackageInvoice>
    )

    private data class PackageImportOutcome(
        val project: Project,
        val isNewProject: Boolean,
        val addedInvoices: List<Invoice>,
        val categoriesToAdd: List<String>,
        val skippedDuplicates: Int,
        val failedFiles: Int
    )

    private val projects = mutableListOf<Project>()
    private val selectedIds = linkedSetOf<String>()
    private var activeProjectId: String? = null
    private var pendingOutput: File? = null
    private var subScreen: String? = null
    private var selectedPersonId: String? = null
    private var pendingUninvoicedUploadId: String? = null
    private val PICK_FILES = 1001
    private val PICK_UNINVOICED_FILE = 1002
    private val PICK_IMPORT_PACKAGE = 1003
    private var pendingImportTargetProjectId: String? = null

    private val pine = Color.rgb(25, 63, 53)
    private val pineLight = Color.rgb(230, 240, 235)
    private val page = Color.rgb(246, 247, 244)
    private val ink = Color.rgb(31, 43, 39)
    private val muted = Color.rgb(112, 124, 118)
    private val line = Color.rgb(224, 231, 226)
    private val white = Color.WHITE

    private lateinit var homeProjectList: LinearLayout
    private lateinit var projectNameInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var filterSpinner: Spinner
    private lateinit var invoiceListLayout: LinearLayout
    private lateinit var statusText: TextView
    private val statValues = mutableListOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = pine
        window.navigationBarColor = page
        PDFBoxResourceLoader.init(applicationContext)
        loadState()
        buildHomeUi()
    }

    override fun onBackPressed() {
        when (subScreen) {
            "person" -> {
                subScreen = "unpaid"
                selectedPersonId = null
                buildUnpaidUi()
            }
            "unpaid", "uninvoiced" -> {
                subScreen = null
                selectedPersonId = null
                buildDetailUi()
            }
            else -> if (activeProjectId != null) {
                activeProjectId = null
                selectedIds.clear()
                pendingOutput = null
                subScreen = null
                buildHomeUi()
            } else super.onBackPressed()
        }
    }

    private fun currentProject(): Project? = projects.firstOrNull { it.id == activeProjectId }

    private fun buildHomeUi() {
        activeProjectId = null
        subScreen = null
        selectedPersonId = null
        statValues.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(23), dp(25), dp(23), dp(24))
            background = rounded(pine, 0)
        }
        header.addView(text("发票小管家合作版", 27f, white, true))
        header.addView(text("项目清晰，发票不乱", 14f, Color.rgb(213, 229, 219)).apply {
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(header, matchWrap())

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(17), dp(18), dp(17), dp(26))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(12))
        }
        titleRow.addView(text("我的项目", 23f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(text("${projects.size} 个项目", 12f, pine, true).apply {
            background = rounded(pineLight, 30)
            setPadding(dp(12), dp(7), dp(12), dp(7))
        })
        body.addView(titleRow)
        body.addView(actionButton("导入成员项目分享包", pineLight, pine, 14f) {
            requestImportPackage(null)
        }, matchWrap().apply { bottomMargin = dp(13) })
        body.addView(text("成员可把整理好的发票、PDF、分类和备注打成一个分享包；你选择目标项目后即可批量导入。离线版会分享一个 ZIP 文件，不会自动生成互联网链接；如使用云盘链接，先下载 ZIP 再导入。", 12f, muted).apply {
            setPadding(dp(3), 0, dp(3), dp(11))
        })

        homeProjectList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(homeProjectList, matchWrap())

        val createCard = cardContainer().apply { setPadding(dp(17), dp(18), dp(17), dp(18)) }
        createCard.addView(text("新建项目", 19f, ink, true))
        createCard.addView(text("每个项目的发票、分类和合并操作互相独立。", 13f, muted).apply {
            setPadding(0, dp(6), 0, dp(12))
        })
        projectNameInput = EditText(this).apply {
            hint = "例如：2026年纪录片项目"
            textSize = 15f
            isSingleLine = true
            setTextColor(ink)
            setHintTextColor(Color.rgb(155, 164, 158))
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = rounded(white, 14, line, 1)
        }
        createCard.addView(projectNameInput, LinearLayout.LayoutParams(-1, dp(52)))
        createCard.addView(actionButton("＋  创建项目", pine, white) { createProject() }, LinearLayout.LayoutParams(-1, dp(49)).apply {
            topMargin = dp(12)
        })
        body.addView(createCard, matchWrap().apply { topMargin = dp(18) })
        body.addView(text("数据仅保存在这台手机的应用空间内。删除项目时，只删除应用保存的副本，不会删除相册或下载目录里的原文件。", 12f, muted).apply {
            setPadding(dp(5), dp(13), dp(5), 0)
        })
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshHomeProjects()
    }

    private fun refreshHomeProjects() {
        if (!::homeProjectList.isInitialized) return
        homeProjectList.removeAllViews()
        if (projects.isEmpty()) {
            val empty = cardContainer().apply { setPadding(dp(18), dp(19), dp(18), dp(19)) }
            empty.addView(text("还没有项目", 17f, ink, true))
            empty.addView(text("先创建一个项目，再把对应发票导入其中。", 13f, muted).apply { setPadding(0, dp(5), 0, 0) })
            homeProjectList.addView(empty, matchWrap())
            return
        }
        projects.forEachIndexed { index, project ->
            val outer = cardContainer().apply {
                setPadding(dp(13), dp(13), dp(8), dp(13))
                isClickable = true
                setOnClickListener { openProject(project.id) }
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val folder = TextView(this).apply {
                text = "▤"
                textSize = 26f
                gravity = Gravity.CENTER
                setTextColor(pine)
                background = rounded(pineLight, 15)
            }
            row.addView(folder, LinearLayout.LayoutParams(dp(52), dp(52)))
            val details = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(13), 0, dp(7), 0)
            }
            details.addView(text(project.name, 17f, ink, true))
            details.addView(text("${project.categories.size} 个分类  ·  ${project.invoices.size} 张发票", 12.5f, muted).apply {
                setPadding(0, dp(5), 0, 0)
            })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("›", 30f, muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(27), dp(48)))
            outer.addView(row)
            // A separate menu button preserves the simple tap-to-open card interaction.
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            actions.addView(actionButton("项目管理  ⋯", pineLight, pine, 12f) { showProjectActions(project) }, LinearLayout.LayoutParams(-2, dp(35)))
            outer.addView(actions, matchWrap().apply { topMargin = dp(7) })
            homeProjectList.addView(outer, matchWrap().apply { bottomMargin = dp(11) })
        }
    }

    private fun createProject() {
        val name = projectNameInput.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "先给项目起个名字", Toast.LENGTH_SHORT).show()
            return
        }
        if (projects.any { it.name.equals(name, ignoreCase = true) }) {
            Toast.makeText(this, "已经有同名项目了，请换个名称", Toast.LENGTH_SHORT).show()
            return
        }
        val project = Project(UUID.randomUUID().toString(), name)
        projects.add(project)
        persistState()
        openProject(project.id)
    }

    private fun showProjectActions(project: Project) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(project.name)
            .setItems(arrayOf("重命名项目", "删除整个项目")) { _, which ->
                if (which == 0) renameProject(project) else confirmDeleteProject(project)
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun renameProject(project: Project) {
        val input = EditText(this).apply {
            setText(project.name)
            setSelection(text.length)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("重命名项目")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    project.name = name
                    persistState()
                    if (activeProjectId == project.id) buildDetailUi() else buildHomeUi()
                }
            }
            .show()
    }

    private fun confirmDeleteProject(project: Project) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("删除整个项目？")
            .setMessage("将删除“${project.name}”以及发票小管家保存的文件副本和记录。不会删除手机相册、下载目录里的原始文件。此操作无法撤销。")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除项目") { _, _ ->
                deleteRecursively(File(filesDir, "projectFiles/${project.id}"))
                projects.removeAll { it.id == project.id }
                if (activeProjectId == project.id) activeProjectId = null
                selectedIds.clear()
                pendingOutput = null
                persistState()
                buildHomeUi()
            }
            .show()
    }

    private fun openProject(id: String) {
        if (projects.none { it.id == id }) return
        activeProjectId = id
        subScreen = null
        selectedPersonId = null
        selectedIds.clear()
        pendingOutput = null
        buildDetailUi()
    }

    private fun buildDetailUi() {
        val project = currentProject() ?: run { buildHomeUi(); return }
        statValues.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(16), dp(14), dp(17))
            background = rounded(pine, 0)
        }
        header.addView(actionButton("‹", pine, white, 29f) {
            activeProjectId = null
            selectedIds.clear()
            pendingOutput = null
            buildHomeUi()
        }, LinearLayout.LayoutParams(dp(42), dp(46)))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, dp(7), 0)
        }
        heading.addView(text(project.name, 20f, white, true, maxLines = 1))
        heading.addView(text("项目发票 · 分类归档", 12f, Color.rgb(211, 227, 217)).apply { setPadding(0, dp(3), 0, 0) })
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(actionButton("⋯", pine, white, 23f) { showProjectActions(project) }, LinearLayout.LayoutParams(dp(40), dp(44)))
        root.addView(header, matchWrap())

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(14), dp(14), dp(14), dp(15))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val overview = cardContainer().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        overview.addView(text("发票概览", 18f, ink, true))
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        listOf("全部文件", "图片", "PDF", "已选择").forEachIndexed { idx, label ->
            val stat = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(9), dp(9), dp(5), dp(9))
                background = rounded(pineLight, 13)
            }
            val value = text("0", 22f, ink, true)
            statValues.add(value)
            stat.addView(value)
            stat.addView(text(label, 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
            statsRow.addView(stat, LinearLayout.LayoutParams(0, dp(76), 1f).apply {
                if (idx > 0) leftMargin = dp(6)
            })
        }
        overview.addView(statsRow)
        body.addView(overview, matchWrap().apply { bottomMargin = dp(13) })

        // Two project-level workflows: outstanding payments and invoices still to be collected.
        val workflowRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pendingPayments = project.paymentPeople.count { !it.paid }
        val unpaidCard = actionButton("未打款\n$pendingPayments 人", Color.rgb(255, 242, 220), Color.rgb(135, 83, 20), 14f) {
            subScreen = "unpaid"
            buildUnpaidUi()
        }
        val uninvoicedCard = actionButton("未开发票\n${project.uninvoicedRecords.size} 条", Color.rgb(250, 229, 226), Color.rgb(155, 57, 48), 14f) {
            subScreen = "uninvoiced"
            buildUninvoicedUi()
        }
        workflowRow.addView(unpaidCard, LinearLayout.LayoutParams(0, dp(62), 1f))
        workflowRow.addView(uninvoicedCard, LinearLayout.LayoutParams(0, dp(62), 1f).apply { leftMargin = dp(9) })
        body.addView(workflowRow, matchWrap().apply { bottomMargin = dp(13) })

        val collaborationCard = cardContainer().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        collaborationCard.addView(text("③  团队项目分享", 18f, ink, true))
        collaborationCard.addView(text("成员先在自己的合作版里整理发票，分享一个项目包；负责人可以导入到本项目，不必逐张接收图片。", 12f, muted).apply {
            setPadding(0, dp(6), 0, dp(9))
        })
        collaborationCard.addView(actionButton("分享本项目给负责人", pine, white, 14f) {
            shareProjectPackage(project)
        }, LinearLayout.LayoutParams(-1, dp(46)))
        collaborationCard.addView(actionButton("导入成员项目包到当前项目", pineLight, pine, 13f) {
            requestImportPackage(project.id)
        }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })
        collaborationCard.addView(text("分享内容包括：项目分类、发票图片 / PDF、每张发票的备注。未打款和未开发票台账不会随分享包传输。", 11.5f, muted).apply {
            setPadding(0, dp(8), 0, 0)
        })
        body.addView(collaborationCard, matchWrap().apply { bottomMargin = dp(13) })

        val importCard = cardContainer().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        importCard.addView(text("①  导入发票", 18f, ink, true))
        importCard.addView(text("选择新导入发票所属的分类", 12f, muted).apply { setPadding(0, dp(9), 0, dp(5)) })
        val categoryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        categorySpinner = Spinner(this)
        updateCategorySpinner()
        categoryRow.addView(categorySpinner, LinearLayout.LayoutParams(0, dp(48), 1f))
        categoryRow.addView(actionButton("＋ 新分类", pineLight, pine, 13f) { addCategoryDialog() }, LinearLayout.LayoutParams(-2, dp(47)).apply { leftMargin = dp(8) })
        importCard.addView(categoryRow)
        importCard.addView(actionButton("＋ 选择图片 / PDF", pine, white, 15f) { pickFiles() }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })
        importCard.addView(text("图片和 PDF 会复制保存到本项目。删除项目只会删除应用里的副本，不会动原文件。", 12f, muted).apply {
            setPadding(0, dp(9), 0, 0)
        })
        body.addView(importCard, matchWrap().apply { bottomMargin = dp(13) })

        val listCard = cardContainer().apply { setPadding(dp(16), dp(15), dp(16), dp(10)) }
        val listHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listHeading.addView(text("②  分类查看", 18f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        listCard.addView(listHeading)
        filterSpinner = Spinner(this)
        updateFilterSpinner()
        listCard.addView(filterSpinner, matchWrap().apply { topMargin = dp(7); bottomMargin = dp(7) })
        val selectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        selectRow.addView(actionButton("全选当前分类", pineLight, pine, 12f) { selectCurrentVisible() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        selectRow.addView(actionButton("取消选择", pineLight, pine, 12f) {
            selectedIds.clear(); refreshInvoiceList()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        listCard.addView(selectRow)
        invoiceListLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.addView(invoiceListLayout, matchWrap().apply { topMargin = dp(9) })
        body.addView(listCard, matchWrap())
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(12))
            background = rounded(white, 17, line, 1)
        }
        statusText = text("发票只保存在当前项目中。", 12f, muted).apply {
            setPadding(dp(2), 0, dp(2), dp(6))
        }
        footer.addView(statusText)
        footer.addView(actionButton("一键合并所选为 PDF", pine, white, 15f) { mergeSelected() }, LinearLayout.LayoutParams(-1, dp(47)))
        footer.addView(actionButton("分享 / 发送生成的 PDF", pineLight, pine, 14f) { shareLast() }, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(7) })
        root.addView(footer, matchWrap())

        setContentView(root)
        filterSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { refreshInvoiceList() }
        }
        refreshInvoiceList()
    }

    private fun featureHeader(title: String, subtitle: String, onBack: () -> Unit): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(15), dp(14), dp(15))
            background = rounded(pine, 0)
        }
        header.addView(actionButton("‹", pine, white, 29f, onBack), LinearLayout.LayoutParams(dp(42), dp(46)))
        val titleColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        titleColumn.addView(text(title, 19f, white, true))
        titleColumn.addView(text(subtitle, 12f, Color.rgb(211, 227, 217)).apply { setPadding(0, dp(3), 0, 0) })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        return header
    }

    private fun featurePageRoot(title: String, subtitle: String, onBack: () -> Unit): Pair<LinearLayout, LinearLayout> {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(page)
        }
        root.addView(featureHeader(title, subtitle, onBack), matchWrap())
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(dp(14), dp(14), dp(14), dp(22))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return Pair(root, body)
    }

    private fun unpaidPeople(): List<PaymentPerson> = currentProject()?.paymentPeople?.filter { !it.paid } ?: emptyList()

    private fun sumExpenses(person: PaymentPerson): Double = person.expenses.sumOf { it.amount }

    private fun money(value: Double): String = "¥" + String.format(Locale.CHINA, "%.2f", value)

    private fun todayString(): String = SimpleDateFormat("yyyy.MM.dd", Locale.CHINA).format(Date())

    private fun buildUnpaidUi() {
        val project = currentProject() ?: return
        subScreen = "unpaid"
        val (root, body) = featurePageRoot("未打款", "记录报销人、开销和发票状态") {
            subScreen = null
            selectedPersonId = null
            buildDetailUi()
        }
        val people = unpaidPeople()
        val totalRecords = people.sumOf { it.expenses.size }
        val totalAmount = people.sumOf { sumExpenses(it) }
        val stats = cardContainer().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        stats.addView(text("待打款统计", 18f, ink, true))
        val statsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        listOf(Triple(people.size.toString(), "待打款人数", 1f), Triple(totalRecords.toString(), "开销记录", 1f), Triple(money(totalAmount), "待打款总额", 1f)).forEachIndexed { idx, item ->
            val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(pineLight, 13); setPadding(dp(9), dp(10), dp(5), dp(10)) }
            c.addView(text(item.first, if (idx == 2) 17f else 21f, if (idx == 2) Color.rgb(174, 48, 40) else ink, true, maxLines = 1))
            c.addView(text(item.second, 10.5f, muted).apply { setPadding(0, dp(4), 0, 0) })
            statsRow.addView(c, LinearLayout.LayoutParams(0, dp(72), item.third).apply { if (idx > 0) leftMargin = dp(6) })
        }
        stats.addView(statsRow)
        body.addView(stats, matchWrap().apply { bottomMargin = dp(12) })
        body.addView(text("待打款人员", 18f, ink, true).apply { setPadding(dp(2), dp(5), 0, dp(9)) })
        if (people.isEmpty()) {
            body.addView(cardContainer().apply {
                setPadding(dp(16), dp(20), dp(16), dp(20))
                addView(text("暂无待打款记录", 15f, ink, true))
                addView(text("新建报销人，录入每笔开销，系统会自动统计应付总额。", 12f, muted).apply { setPadding(0, dp(6), 0, 0) })
            }, matchWrap().apply { bottomMargin = dp(10) })
        } else {
            people.forEach { person ->
                val card = cardContainer().apply { setPadding(dp(13), dp(13), dp(13), dp(12)) }
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(text(person.name, 17f, ink, true))
                info.addView(text("${person.expenses.size} 条开销记录", 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
                top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(text(money(sumExpenses(person)), 18f, Color.rgb(177, 46, 39), true))
                card.addView(top)
                val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
                buttons.addView(actionButton("查看 / 编辑明细", pineLight, pine, 12f) {
                    selectedPersonId = person.id
                    subScreen = "person"
                    buildPersonUi()
                }, LinearLayout.LayoutParams(0, dp(39), 1f))
                buttons.addView(actionButton("确认已打款", Color.rgb(230, 240, 235), pine, 12f) { confirmPersonPaid(person) }, LinearLayout.LayoutParams(0, dp(39), 1f).apply { leftMargin = dp(8) })
                card.addView(buttons)
                body.addView(card, matchWrap().apply { bottomMargin = dp(9) })
            }
        }
        body.addView(actionButton("＋ 新建报销人", pine, white, 15f) { createPaymentPersonDialog() }, matchWrap().apply { topMargin = dp(5) })
        body.addView(text("每个人可以添加多笔开销；红色代表未给发票，绿色代表已给发票。确认转账后可将人员标记为已打款。", 12f, muted).apply { setPadding(dp(3), dp(10), dp(3), 0) })
        setContentView(root)
    }

    private fun createPaymentPersonDialog() {
        val project = currentProject() ?: return
        val input = AutoCompleteTextView(this).apply {
            hint = "姓名，例如：张三"
            threshold = 1
            setTextColor(ink)
            setHintTextColor(muted)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(white, 12, line, 1)
            setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, project.paymentPeople.map { it.name }.distinct()))
        }
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0); addView(input, LinearLayout.LayoutParams(-1, dp(52))) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("新建报销人")
            .setMessage("输入姓名后，可为此人添加多笔开销记录。")
            .setView(wrap)
            .setNegativeButton("取消", null)
            .setPositiveButton("创建并添加开销", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = input.text.toString().trim()
                if (name.isBlank()) {
                    input.error = "请填写姓名"
                    return@setOnClickListener
                }
                val existing = project.paymentPeople.firstOrNull { it.name.equals(name, true) && !it.paid }
                val person = existing ?: PaymentPerson(UUID.randomUUID().toString(), name).also { project.paymentPeople.add(it) }
                persistState()
                dialog.dismiss()
                selectedPersonId = person.id
                subScreen = "person"
                buildPersonUi()
                showExpenseForm(person, null)
            }
        }
        dialog.show()
    }

    private fun getSelectedPerson(): PaymentPerson? = currentProject()?.paymentPeople?.firstOrNull { it.id == selectedPersonId }

    private fun buildPersonUi() {
        val project = currentProject() ?: return
        val person = getSelectedPerson() ?: run { subScreen = "unpaid"; buildUnpaidUi(); return }
        subScreen = "person"
        val (root, body) = featurePageRoot(person.name, "个人开销明细 · 待打款 ${money(sumExpenses(person))}") {
            subScreen = "unpaid"
            selectedPersonId = null
            buildUnpaidUi()
        }
        val summary = cardContainer().apply { setPadding(dp(15), dp(15), dp(15), dp(15)) }
        summary.addView(text("${person.expenses.size} 笔开销", 13f, muted))
        summary.addView(text("应付总额  ${money(sumExpenses(person))}", 23f, Color.rgb(177, 46, 39), true).apply { setPadding(0, dp(5), 0, 0) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, 0) }
        actions.addView(actionButton("修改姓名", pineLight, pine, 12f) { renamePaymentPerson(person) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        actions.addView(actionButton("确认已打款", Color.rgb(230, 240, 235), pine, 12f) { confirmPersonPaid(person) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(8) })
        summary.addView(actions)
        body.addView(summary, matchWrap().apply { bottomMargin = dp(12) })
        body.addView(text("开销记录", 17f, ink, true).apply { setPadding(dp(2), dp(4), 0, dp(9)) })
        if (person.expenses.isEmpty()) {
            body.addView(text("还没有开销，点击下方按钮添加。", 13f, muted).apply { setPadding(dp(8), dp(14), dp(8), dp(14)) })
        }
        person.expenses.forEach { expense ->
            val card = cardContainer().apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }
            val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(expense.description, 15f, ink, true, maxLines = 3))
            details.addView(text(expense.date, 11.5f, muted).apply { setPadding(0, dp(4), 0, 0) })
            firstRow.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            firstRow.addView(text(money(expense.amount), 17f, Color.rgb(177, 46, 39), true))
            card.addView(firstRow)
            val tagRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            tagRow.addView(actionButton(if (expense.hasInvoice) "✓ 已给发票" else "○ 未给发票", if (expense.hasInvoice) pineLight else Color.rgb(250, 229, 226), if (expense.hasInvoice) pine else Color.rgb(155, 57, 48), 11f) {
                expense.hasInvoice = !expense.hasInvoice
                persistState()
                buildPersonUi()
            }, LinearLayout.LayoutParams(0, dp(36), 1f))
            tagRow.addView(actionButton("编辑", pineLight, pine, 11f) { showExpenseForm(person, expense) }, LinearLayout.LayoutParams(dp(60), dp(36)).apply { leftMargin = dp(6) })
            tagRow.addView(actionButton("删除", Color.rgb(247, 239, 235), Color.rgb(140, 70, 56), 11f) {
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("删除这笔开销？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("删除") { _, _ -> person.expenses.removeAll { it.id == expense.id }; persistState(); buildPersonUi() }
                    .show()
            }, LinearLayout.LayoutParams(dp(60), dp(36)).apply { leftMargin = dp(6) })
            card.addView(tagRow)
            body.addView(card, matchWrap().apply { bottomMargin = dp(8) })
        }
        body.addView(actionButton("＋ 新增一笔开销", pine, white, 15f) { showExpenseForm(person, null) }, matchWrap().apply { topMargin = dp(5) })
        body.addView(text("发票状态可以随时修改；应付总额会根据此人的所有开销自动计算。", 12f, muted).apply { setPadding(dp(3), dp(10), dp(3), 0) })
        setContentView(root)
    }

    private fun renamePaymentPerson(person: PaymentPerson) {
        val input = EditText(this).apply { setText(person.name); hint = "姓名"; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("修改姓名")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotBlank()) { person.name = name; persistState(); buildPersonUi() }
            }
            .show()
    }

    private fun confirmPersonPaid(person: PaymentPerson) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("确认已打款？")
            .setMessage("确认已向“${person.name}”支付 ${money(sumExpenses(person))}？确认后此人会从“未打款”列表中移除，记录仍保存在项目中。")
            .setNegativeButton("再检查一下", null)
            .setPositiveButton("确认已打款") { _, _ ->
                person.paid = true
                persistState()
                selectedPersonId = null
                subScreen = "unpaid"
                buildUnpaidUi()
            }
            .show()
    }

    private fun showExpenseForm(person: PaymentPerson, existing: ExpenseItem?) {
        val dateInput = EditText(this).apply { hint = "日期，例如：2026.10.12"; setText(existing?.date ?: todayString()); setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1) }
        val descInput = EditText(this).apply { hint = "事项，例如：10.12日餐费"; setText(existing?.description ?: ""); setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1) }
        val amountInput = EditText(this).apply { hint = "金额，例如：50"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""); setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1) }
        val statusGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val invoiceYes = RadioButton(this).apply { text = "已给发票"; id = View.generateViewId(); buttonTintList = ColorStateList.valueOf(pine) }
        val invoiceNo = RadioButton(this).apply { text = "未给发票"; id = View.generateViewId(); buttonTintList = ColorStateList.valueOf(Color.rgb(190, 63, 54)) }
        statusGroup.addView(invoiceYes, RadioGroup.LayoutParams(0, -2, 1f))
        statusGroup.addView(invoiceNo, RadioGroup.LayoutParams(0, -2, 1f))
        statusGroup.check(if (existing?.hasInvoice == true) invoiceYes.id else invoiceNo.id)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0) }
        fun addField(label: String, field: View) {
            form.addView(text(label, 12f, muted, true).apply { setPadding(dp(1), dp(7), 0, dp(5)) })
            form.addView(field, LinearLayout.LayoutParams(-1, dp(46)))
        }
        addField("日期", dateInput)
        addField("事项说明", descInput)
        addField("金额（元）", amountInput)
        form.addView(text("发票状态", 12f, muted, true).apply { setPadding(dp(1), dp(9), 0, dp(3)) })
        form.addView(statusGroup)
        val scroll = ScrollView(this).apply { addView(form) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(if (existing == null) "新增开销 · ${person.name}" else "编辑开销 · ${person.name}")
            .setView(scroll)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val date = dateInput.text.toString().trim()
                val description = descInput.text.toString().trim()
                val amount = amountInput.text.toString().trim().toDoubleOrNull()
                if (date.isBlank() || description.isBlank() || amount == null || amount < 0) {
                    Toast.makeText(this, "请填写日期、事项和有效金额", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val hasInvoice = statusGroup.checkedRadioButtonId == invoiceYes.id
                if (existing == null) person.expenses.add(ExpenseItem(UUID.randomUUID().toString(), date, description, amount, hasInvoice))
                else { existing.date = date; existing.description = description; existing.amount = amount; existing.hasInvoice = hasInvoice }
                persistState()
                dialog.dismiss()
                buildPersonUi()
            }
        }
        dialog.show()
    }

    private fun buildUninvoicedUi() {
        val project = currentProject() ?: return
        subScreen = "uninvoiced"
        val (root, body) = featurePageRoot("未开发票", "登记开票事项，收到发票后补齐归档") {
            subScreen = null
            buildDetailUi()
        }
        val total = project.uninvoicedRecords.sumOf { it.amount }
        val stats = cardContainer().apply { setPadding(dp(16), dp(15), dp(16), dp(15)) }
        stats.addView(text("待补开发票统计", 17f, ink, true))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, 0) }
        row.addView(text("${project.uninvoicedRecords.size} 条记录", 13f, muted), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text("涉及金额  ${money(total)}", 19f, Color.rgb(177, 46, 39), true))
        stats.addView(row)
        body.addView(stats, matchWrap().apply { bottomMargin = dp(12) })
        if (project.uninvoicedRecords.isEmpty()) {
            body.addView(cardContainer().apply {
                setPadding(dp(16), dp(22), dp(16), dp(22))
                addView(text("暂无待补开发票记录", 15f, ink, true))
                addView(text("把需要开票的日期、事项和金额记下来，发票收到后上传即可归档。", 12f, muted).apply { setPadding(0, dp(6), 0, 0) })
            }, matchWrap().apply { bottomMargin = dp(10) })
        } else {
            project.uninvoicedRecords.forEach { record ->
                val card = cardContainer().apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }
                val first = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(text("${record.date} ${record.description}", 14f, ink, true, maxLines = 4))
                info.addView(text(money(record.amount), 17f, Color.rgb(177, 46, 39), true).apply { setPadding(0, dp(5), 0, 0) })
                first.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val status = TextView(this).apply {
                    text = "● 未上传发票"
                    textSize = 10.5f
                    setTextColor(Color.rgb(164, 47, 40))
                    background = rounded(Color.rgb(250, 229, 226), 13)
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                }
                first.addView(status)
                card.addView(first)
                val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
                buttons.addView(actionButton("＋ 上传发票", pine, white, 12f) { pickInvoiceForUninvoiced(record.id) }, LinearLayout.LayoutParams(0, dp(39), 1f))
                buttons.addView(actionButton("编辑", pineLight, pine, 12f) { showUninvoicedForm(record) }, LinearLayout.LayoutParams(dp(65), dp(39)).apply { leftMargin = dp(7) })
                buttons.addView(actionButton("删除", Color.rgb(247, 239, 235), Color.rgb(140, 70, 56), 12f) {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("删除这条未开发票记录？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除") { _, _ -> project.uninvoicedRecords.removeAll { it.id == record.id }; persistState(); buildUninvoicedUi() }
                        .show()
                }, LinearLayout.LayoutParams(dp(65), dp(39)).apply { leftMargin = dp(7) })
                card.addView(buttons)
                body.addView(card, matchWrap().apply { bottomMargin = dp(9) })
            }
        }
        body.addView(actionButton("＋ 新建未开发票记录", pine, white, 15f) { showUninvoicedForm(null) }, matchWrap().apply { topMargin = dp(5) })
        body.addView(text("未上传的记录会以红色状态标识。上传后确认补齐，记录会自动转入项目发票列表的“补开发票中”分类，并把日期、事项和金额完整写入发票备注。", 12f, muted).apply { setPadding(dp(3), dp(10), dp(3), 0) })
        setContentView(root)
    }

    private fun showUninvoicedForm(existing: UninvoicedRecord?) {
        val project = currentProject() ?: return
        val dateInput = EditText(this).apply { hint = "日期，例如：2026.10.12"; setText(existing?.date ?: todayString()); setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1) }
        val descInput = EditText(this).apply { hint = "例如：北京张三影视公司租赁"; setText(existing?.description ?: ""); minLines = 2; maxLines = 4; setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1); gravity = Gravity.TOP or Gravity.START }
        val amountInput = EditText(this).apply { hint = "金额，例如：500"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(existing?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: ""); setSingleLine(true); setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(white, 10, line, 1) }
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0) }
        fun addField(label: String, field: View, height: Int) {
            form.addView(text(label, 12f, muted, true).apply { setPadding(dp(1), dp(7), 0, dp(5)) })
            form.addView(field, LinearLayout.LayoutParams(-1, dp(height)))
        }
        addField("日期", dateInput, 46)
        addField("事项说明 / 备注", descInput, 82)
        addField("金额（元）", amountInput, 46)
        form.addView(text("可先保存待办，再上传发票；也可点击“保存并上传”直接选择发票。", 11.5f, muted).apply { setPadding(0, dp(9), 0, 0) })
        val scroll = ScrollView(this).apply { addView(form) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(if (existing == null) "新建未开发票记录" else "编辑未开发票记录")
            .setView(scroll)
            .setNegativeButton("取消", null)
            .setNeutralButton("保存并上传", null)
            .setPositiveButton("保存", null)
            .create()
        dialog.setOnShowListener {
            fun saveRecord(andUpload: Boolean) {
                val date = dateInput.text.toString().trim()
                val description = descInput.text.toString().trim()
                val amount = amountInput.text.toString().trim().toDoubleOrNull()
                if (date.isBlank() || description.isBlank() || amount == null || amount < 0) {
                    Toast.makeText(this, "请填写日期、事项和有效金额", Toast.LENGTH_SHORT).show()
                    return
                }
                val record = if (existing == null) UninvoicedRecord(UUID.randomUUID().toString(), date, description, amount).also { project.uninvoicedRecords.add(it) }
                else existing.apply { this.date = date; this.description = description; this.amount = amount }
                persistState()
                dialog.dismiss()
                if (andUpload) pickInvoiceForUninvoiced(record.id) else buildUninvoicedUi()
            }
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener { saveRecord(false) }
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener { saveRecord(true) }
        }
        dialog.show()
    }

    private fun pickInvoiceForUninvoiced(recordId: String) {
        pendingUninvoicedUploadId = recordId
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_UNINVOICED_FILE)
    }

    private fun confirmUninvoicedTransfer(recordId: String, uri: Uri) {
        val project = currentProject() ?: return
        val record = project.uninvoicedRecords.firstOrNull { it.id == recordId } ?: run { pendingUninvoicedUploadId = null; return }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("是否确认补齐发票？")
            .setMessage("确认后，这条未开发票记录将转入项目发票列表的“补开发票中”分类；日期、事项和金额会保存为发票备注，并从未开发票列表移除。")
            .setNegativeButton("取消") { _, _ -> pendingUninvoicedUploadId = null; if (subScreen == "uninvoiced") buildUninvoicedUi() }
            .setPositiveButton("确认补齐") { _, _ ->
                try {
                    val name = queryName(uri) ?: "补开发票_${record.date}"
                    val mime = contentResolver.getType(uri) ?: ""
                    val isPdf = mime.equals("application/pdf", true) || name.lowercase(Locale.ROOT).endsWith(".pdf")
                    val isImage = mime.startsWith("image/") || name.lowercase(Locale.ROOT).let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") || it.endsWith(".heic") }
                    if (!isPdf && !isImage) throw IllegalArgumentException("只支持图片和 PDF 文件")
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                    val copy = copyUriIntoProject(uri, project, name, isPdf)
                    if (!project.categories.contains("补开发票中")) project.categories.add("补开发票中")
                    val amountText = if (record.amount % 1.0 == 0.0) record.amount.toLong().toString() else record.amount.toString()
                    val fullNote = "${record.date} ${record.description} ${amountText}元"
                    project.invoices.add(Invoice(UUID.randomUUID().toString(), name, "补开发票中", isPdf, copy.absolutePath, uri.toString(), fullNote))
                    project.uninvoicedRecords.removeAll { it.id == record.id }
                    persistState()
                    pendingUninvoicedUploadId = null
                    subScreen = null
                    selectedIds.clear()
                    buildDetailUi()
                    if (::filterSpinner.isInitialized) {
                        val idx = (0 until filterSpinner.count).firstOrNull { filterSpinner.getItemAtPosition(it).toString() == "补开发票中" }
                        if (idx != null) filterSpinner.setSelection(idx)
                    }
                    Toast.makeText(this, "发票已补齐，已转入“补开发票中”，原事项已保存到发票备注。", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "补齐失败：${e.message ?: "无法读取文件"}", Toast.LENGTH_LONG).show()
                }
            }
            .show()
    }

    private fun updateCategorySpinner() {
        val project = currentProject() ?: return
        categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, project.categories).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun updateFilterSpinner() {
        val project = currentProject() ?: return
        filterSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listOf("全部") + project.categories).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun addCategoryDialog() {
        val project = currentProject() ?: return
        val input = EditText(this).apply {
            hint = "例如：差旅、采购、后期制作"
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("在“${project.name}”中新建分类")
            .setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("添加") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                if (project.categories.contains(name)) {
                    Toast.makeText(this, "这个分类已经存在", Toast.LENGTH_SHORT).show()
                } else {
                    project.categories.add(name)
                    persistState()
                    updateCategorySpinner()
                    updateFilterSpinner()
                    refreshInvoiceList()
                }
            }
            .show()
    }

    private fun pickFiles() {
        if (currentProject() == null) return
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_FILES)
    }

    @Deprecated("legacy callback for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMPORT_PACKAGE) {
            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                val uri = data.data!!
                val requestedTarget = pendingImportTargetProjectId
                pendingImportTargetProjectId = null
                Toast.makeText(this, "正在读取项目分享包…", Toast.LENGTH_SHORT).show()
                Thread {
                    var copiedZip: File? = null
                    try {
                        copiedZip = File(cacheDir, "incoming_project_${UUID.randomUUID()}.zip")
                        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法读取所选文件")
                        input.use { source -> FileOutputStream(copiedZip!!).use { target -> source.copyTo(target) } }
                        val pack = readProjectSharePackage(copiedZip!!)
                        runOnUiThread { handleLoadedProjectPackage(copiedZip!!, pack, requestedTarget) }
                    } catch (e: Exception) {
                        copiedZip?.delete()
                        runOnUiThread {
                            AlertDialog.Builder(this)
                                .setTitle("无法读取项目分享包")
                                .setMessage(e.message ?: "请确认选择的是由“发票小管家合作版”导出的项目 ZIP 包。")
                                .setPositiveButton("知道了", null)
                                .show()
                        }
                    }
                }.start()
            } else {
                pendingImportTargetProjectId = null
            }
            return
        }
        if (requestCode == PICK_UNINVOICED_FILE) {
            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                val recordId = pendingUninvoicedUploadId
                val uri = data.data!!
                if (recordId != null) confirmUninvoicedTransfer(recordId, uri)
            } else {
                pendingUninvoicedUploadId = null
                if (subScreen == "uninvoiced") buildUninvoicedUi()
            }
            return
        }
        if (requestCode != PICK_FILES || resultCode != Activity.RESULT_OK || data == null) return
        val project = currentProject() ?: return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        val category = if (::categorySpinner.isInitialized) categorySpinner.selectedItem?.toString() ?: "其他" else "其他"
        var imported = 0
        var failed = 0
        uris.forEach { uri ->
            try {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = queryName(uri) ?: "发票_${project.invoices.size + 1}"
                val mime = contentResolver.getType(uri) ?: ""
                val isPdf = mime.equals("application/pdf", true) || name.lowercase(Locale.ROOT).endsWith(".pdf")
                val isImage = mime.startsWith("image/") || name.lowercase(Locale.ROOT).let { it.endsWith(".jpg") || it.endsWith(".jpeg") || it.endsWith(".png") || it.endsWith(".webp") || it.endsWith(".heic") }
                if (!isPdf && !isImage) throw IllegalArgumentException("只支持图片和 PDF")
                val copy = copyUriIntoProject(uri, project, name, isPdf)
                project.invoices.add(Invoice(UUID.randomUUID().toString(), name, category, isPdf, copy.absolutePath, uri.toString()))
                imported++
            } catch (_: Exception) { failed++ }
        }
        persistState()
        refreshInvoiceList()
        statusText.text = if (failed == 0) "已导入 $imported 个文件到“${project.name}”。" else "成功导入 $imported 个，失败 $failed 个；请检查文件格式或读取权限。"
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun copyUriIntoProject(uri: Uri, project: Project, displayName: String, isPdf: Boolean): File {
        val directory = File(filesDir, "projectFiles/${project.id}").apply { mkdirs() }
        var ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext.length !in 2..6 || ext.any { !it.isLetterOrDigit() }) ext = if (isPdf) "pdf" else "jpg"
        val file = File(directory, "${UUID.randomUUID()}.$ext")
        val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("无法读取文件")
        input.use { source -> FileOutputStream(file).use { target -> source.copyTo(target) } }
        return file
    }

    private fun refreshInvoiceList() {
        if (!::invoiceListLayout.isInitialized) return
        val project = currentProject() ?: return
        invoiceListLayout.removeAllViews()
        val filter = if (::filterSpinner.isInitialized) filterSpinner.selectedItem?.toString() ?: "全部" else "全部"
        val visible = project.invoices.filter { filter == "全部" || it.category == filter }
        if (visible.isEmpty()) {
            invoiceListLayout.addView(text("当前分类暂无发票。\n点击上方“选择图片 / PDF”导入文件。", 13f, muted).apply {
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(24), dp(8), dp(24))
            })
        } else {
            visible.forEach { inv ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(2), dp(9), dp(1), dp(9))
                }
                val check = CheckBox(this).apply {
                    buttonTintList = ColorStateList.valueOf(pine)
                    isChecked = selectedIds.contains(inv.id)
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedIds.add(inv.id) else selectedIds.remove(inv.id)
                        refreshStats()
                    }
                }
                row.addView(check, LinearLayout.LayoutParams(dp(39), dp(43)))
                val detail = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(5), 0, dp(4), 0)
                }
                detail.addView(text(inv.name, 13f, ink, true, maxLines = 2))
                detail.addView(text("${inv.category}  ·  ${if (inv.isPdf) "PDF 文件" else "图片"}", 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
                detail.addView(text(
                    if (inv.note.isBlank()) "备注：未填写（可点备注编辑）" else "备注：${inv.note}",
                    11f, if (inv.note.isBlank()) muted else pine, maxLines = 2
                ).apply { setPadding(0, dp(4), 0, 0) })
                row.addView(detail, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actionButton("备注", pineLight, pine, 11f) { editInvoiceNote(project, inv) }, LinearLayout.LayoutParams(dp(57), dp(38)).apply { rightMargin = dp(4) })
                row.addView(actionButton("删除", Color.rgb(247, 239, 235), Color.rgb(140, 70, 56), 11f) {
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("删除这张发票？")
                        .setMessage("只会删除发票小管家内保存的副本，不会删除原始文件。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("删除") { _, _ ->
                            inv.localPath?.let { File(it).delete() }
                            project.invoices.removeAll { it.id == inv.id }
                            selectedIds.remove(inv.id)
                            persistState()
                            refreshInvoiceList()
                        }
                        .show()
                }, LinearLayout.LayoutParams(dp(58), dp(38)))
                invoiceListLayout.addView(row)
                invoiceListLayout.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
            }
        }
        refreshStats()
    }

    private fun editInvoiceNote(project: Project, invoice: Invoice) {
        val input = EditText(this).apply {
            setText(invoice.note)
            hint = "例如：张三，住宿费，日期：3月21日"
            textSize = 15f
            minLines = 3
            maxLines = 7
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(white, 12, line, 1)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(5), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(-1, dp(125)))
            addView(text("备注只属于这张发票；导出 PDF 时会按发票顺序生成备注索引。留空时索引显示“无”。", 12f, muted).apply {
                setPadding(dp(2), dp(8), dp(2), 0)
            })
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("发票备注")
            .setView(container)
            .setNegativeButton("取消", null)
            .setNeutralButton("清空") { _, _ ->
                invoice.note = ""
                persistState()
                refreshInvoiceList()
                Toast.makeText(this, "备注已清空", Toast.LENGTH_SHORT).show()
            }
            .setPositiveButton("保存") { _, _ ->
                invoice.note = input.text.toString().trim()
                persistState()
                refreshInvoiceList()
                Toast.makeText(this, "备注已保存", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun refreshStats() {
        val project = currentProject() ?: return
        if (statValues.size >= 4) {
            statValues[0].text = project.invoices.size.toString()
            statValues[1].text = project.invoices.count { !it.isPdf }.toString()
            statValues[2].text = project.invoices.count { it.isPdf }.toString()
            statValues[3].text = selectedIds.intersect(project.invoices.map { it.id }.toSet()).size.toString()
        }
    }

    private fun selectCurrentVisible() {
        val project = currentProject() ?: return
        val filter = filterSpinner.selectedItem?.toString() ?: "全部"
        project.invoices.filter { filter == "全部" || it.category == filter }.forEach { selectedIds.add(it.id) }
        refreshInvoiceList()
    }

    private fun mergeSelected() {
        val project = currentProject() ?: return
        val chosen = project.invoices.filter { selectedIds.contains(it.id) }
        if (chosen.isEmpty()) {
            statusText.text = "请先勾选要合并的发票。"
            return
        }
        statusText.text = "正在合并 ${chosen.size} 个文件，请稍候……"
        Thread {
            try {
                val merger = PDFMergerUtility()
                val tempDir = File(cacheDir, "invoice_merge").apply { mkdirs() }
                val temps = mutableListOf<File>()
                chosen.forEachIndexed { index, invoice ->
                    val temp = File(tempDir, "part_${index}_${UUID.randomUUID()}.pdf")
                    openInvoiceStream(invoice).use { input ->
                        if (invoice.isPdf) {
                            FileOutputStream(temp).use { output -> input.copyTo(output) }
                        } else {
                            val bitmap = BitmapFactory.decodeStream(input) ?: throw IllegalStateException("无法读取图片：${invoice.name}")
                            val doc = PdfDocument()
                            val info = PdfDocument.PageInfo.Builder(bitmap.width.coerceAtLeast(1), bitmap.height.coerceAtLeast(1), 1).create()
                            val page = doc.startPage(info)
                            page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                            doc.finishPage(page)
                            FileOutputStream(temp).use { output -> doc.writeTo(output) }
                            doc.close()
                            bitmap.recycle()
                        }
                    }
                    temps.add(temp)
                }
                val safeName = project.name.replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(30).ifBlank { "项目" }
                val outputDir = getExternalFilesDir(null) ?: filesDir
                val indexFile = File(tempDir, "invoice_index_${UUID.randomUUID()}.pdf")
                createInvoiceIndexPdf(indexFile, project.name, chosen)
                val output = File(outputDir, "${safeName}_发票合并_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(Date())}.pdf")
                merger.destinationFileName = output.absolutePath
                temps.forEach { merger.addSource(it) }
                // The index is appended after every original invoice, without modifying invoice pages.
                merger.addSource(indexFile)
                merger.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly())
                temps.forEach { it.delete() }
                indexFile.delete()
                runOnUiThread {
                    pendingOutput = output
                    statusText.text = "合并完成：${chosen.size} 个文件，已在 PDF 末尾添加备注索引。点击下方分享按钮发送到微信等应用。"
                }
            } catch (e: Exception) {
                runOnUiThread { statusText.text = "合并失败：${e.message ?: "请检查文件是否损坏或加密"}" }
            }
        }.start()
    }

    /** Creates a printable appendix whose numbered entries follow exactly the same order as the merged invoices. */
    private fun createInvoiceIndexPdf(file: File, projectName: String, invoices: List<Invoice>) {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 42f
        val contentWidth = pageWidth - margin * 2
        val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = pine
            textSize = 22f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val subtitlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = muted
            textSize = 10.5f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val headingPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val bodyPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = ink
            textSize = 11.5f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = line
            strokeWidth = 0.8f
        }

        var pageNumber = 0
        var page: PdfDocument.Page? = null
        var canvas: android.graphics.Canvas? = null
        var y = 0f

        fun finishCurrentPage() {
            val currentPage = page ?: return
            val currentCanvas = canvas
            if (currentCanvas != null) {
                currentCanvas.drawLine(margin, pageHeight - 29f, pageWidth - margin, pageHeight - 29f, linePaint)
                currentCanvas.drawText("发票备注索引 · 第 $pageNumber 页", margin, pageHeight - 16f, subtitlePaint)
            }
            document.finishPage(currentPage)
            page = null
            canvas = null
        }

        fun startPage() {
            finishCurrentPage()
            pageNumber += 1
            val info = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = document.startPage(info)
            canvas = page!!.canvas
            canvas!!.drawColor(Color.WHITE)
            y = margin
            canvas!!.drawText("发票备注索引", margin, y + 22f, titlePaint)
            y += 43f
            canvas!!.drawText("项目：$projectName", margin, y, subtitlePaint)
            y += 16f
            canvas!!.drawText("共 ${invoices.size} 张发票 · 编号按前面合并的发票文件顺序排列", margin, y, subtitlePaint)
            y += 24f
            canvas!!.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 18f
        }

        fun ensureSpace(height: Float) {
            if (page == null || y + height > pageHeight - 43f) startPage()
        }

        fun wrapText(value: String, paint: android.graphics.Paint): List<String> {
            val normalized = value.replace('\n', ' ').replace('\r', ' ')
            if (normalized.isEmpty()) return listOf("")
            val result = mutableListOf<String>()
            var current = StringBuilder()
            normalized.forEach { char ->
                val candidate = current.toString() + char
                if (current.isNotEmpty() && paint.measureText(candidate) > contentWidth) {
                    result.add(current.toString())
                    current = StringBuilder().append(char)
                } else {
                    current.append(char)
                }
            }
            if (current.isNotEmpty()) result.add(current.toString())
            return result
        }

        fun drawWrapped(value: String, paint: android.graphics.Paint, lineHeight: Float) {
            wrapText(value, paint).forEach { lineText ->
                ensureSpace(lineHeight)
                canvas!!.drawText(lineText, margin, y, paint)
                y += lineHeight
            }
        }

        try {
            startPage()
            invoices.forEachIndexed { index, invoice ->
                ensureSpace(24f)
                drawWrapped("发票 ${index + 1}", headingPaint, 18f)
                drawWrapped("文件：${invoice.name}", bodyPaint, 16f)
                drawWrapped("分类：${invoice.category}", bodyPaint, 16f)
                drawWrapped("备注：${invoice.note.trim().ifBlank { "无" }}", bodyPaint, 16f)
                y += 8f
                ensureSpace(8f)
                canvas!!.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 13f
            }
            finishCurrentPage()
            FileOutputStream(file).use { document.writeTo(it) }
        } finally {
            try { finishCurrentPage() } catch (_: Exception) {}
            document.close()
        }
    }

    private fun openInvoiceStream(invoice: Invoice): InputStream {
        val local = invoice.localPath?.let { File(it) }
        if (local != null && local.exists()) return FileInputStream(local)
        val original = invoice.originalUri ?: throw IllegalStateException("找不到文件副本：${invoice.name}")
        return contentResolver.openInputStream(Uri.parse(original)) ?: throw IllegalStateException("无法读取文件：${invoice.name}")
    }

    private fun shareLast() {
        val file = pendingOutput
        if (file == null || !file.exists()) {
            statusText.text = "请先合并发票，再分享生成的 PDF。"
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "发送合并后的发票 PDF"))
        } catch (e: Exception) {
            statusText.text = "打开分享菜单失败：${e.message ?: "请稍后重试"}"
        }
    }

    /** Exports only the shareable project data: categories, invoice files, and invoice notes. */
    private fun shareProjectPackage(project: Project) {
        if (project.invoices.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("项目里还没有发票")
                .setMessage("先导入图片或 PDF，再分享给项目负责人。")
                .setPositiveButton("知道了", null)
                .show()
            return
        }
        Toast.makeText(this, "正在打包图片、PDF 和备注…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val packageFile = createProjectSharePackage(project)
                runOnUiThread {
                    try {
                        val uri = FileProvider.getUriForFile(this, "$packageName.provider", packageFile)
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "application/zip"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            clipData = ClipData.newUri(contentResolver, "发票小管家项目分享包", uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(send, "分享项目包（发票、PDF、分类和备注）"))
                    } catch (e: Exception) {
                        AlertDialog.Builder(this)
                            .setTitle("分享菜单打开失败")
                            .setMessage(e.message ?: "请稍后重试。")
                            .setPositiveButton("确定", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("生成项目分享包失败")
                        .setMessage(e.message ?: "请检查每张发票文件是否还能读取。")
                        .setPositiveButton("确定", null)
                        .show()
                }
            }
        }.start()
    }

    private fun createProjectSharePackage(project: Project): File {
        val shareDir = File(filesDir, "sharePackages").apply { mkdirs() }
        // Keep the most recent few packages to avoid steadily consuming app storage.
        shareDir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(4)?.forEach { it.delete() }
        val safeProject = project.name.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").trim('_').ifBlank { "项目" }.take(40)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val outputFile = File(shareDir, "${safeProject}_${stamp}_${UUID.randomUUID().toString().take(6)}.zip")
        val manifest = JSONObject()
            .put("format", "invoice_manager_project_share")
            .put("formatVersion", 1)
            .put("projectName", project.name)
            .put("exportedAt", System.currentTimeMillis())
        val categoryArray = JSONArray()
        project.categories.forEach { categoryArray.put(it) }
        manifest.put("categories", categoryArray)
        val invoiceArray = JSONArray()

        ZipOutputStream(BufferedOutputStream(FileOutputStream(outputFile))).use { zip ->
            project.invoices.forEachIndexed { index, invoice ->
                val archivePath = "files/${String.format(Locale.ROOT, "%04d", index + 1)}_${UUID.randomUUID()}.${safeExtension(invoice.name, invoice.isPdf)}"
                val entry = ZipEntry(archivePath)
                zip.putNextEntry(entry)
                val local = invoice.localPath?.let { File(it) }
                if (local != null && local.isFile) {
                    FileInputStream(local).use { it.copyTo(zip) }
                } else {
                    val originalUri = invoice.originalUri ?: throw IllegalStateException("找不到文件：${invoice.name}。请重新导入这张发票后再分享。")
                    val originalStream = contentResolver.openInputStream(Uri.parse(originalUri))
                        ?: throw IllegalStateException("无法读取文件：${invoice.name}。请重新导入后再分享。")
                    originalStream.use { it.copyTo(zip) }
                }
                zip.closeEntry()
                invoiceArray.put(JSONObject()
                    .put("name", invoice.name)
                    .put("category", invoice.category)
                    .put("isPdf", invoice.isPdf)
                    .put("note", invoice.note)
                    .put("file", archivePath))
            }
            manifest.put("invoices", invoiceArray)
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
        return outputFile
    }

    private fun safeExtension(name: String, isPdf: Boolean): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return if (ext.length in 2..8 && ext.all { it.isLetterOrDigit() }) ext else if (isPdf) "pdf" else "jpg"
    }

    private fun requestImportPackage(targetProjectId: String?) {
        pendingImportTargetProjectId = targetProjectId
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "application/x-zip"))
            putExtra(Intent.EXTRA_TITLE, "选择成员分享的项目 ZIP 包")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, PICK_IMPORT_PACKAGE)
        } catch (e: Exception) {
            pendingImportTargetProjectId = null
            Toast.makeText(this, "无法打开文件选择器：${e.message ?: "请重试"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun readProjectSharePackage(zipFile: File): ProjectSharePackage {
        ZipFile(zipFile).use { zip ->
            val entry = zip.getEntry("manifest.json") ?: throw IllegalArgumentException("ZIP 包里没有 manifest.json，不是有效的项目分享包。")
            if (entry.size > 8L * 1024L * 1024L) throw IllegalArgumentException("项目分享包的清单异常，无法安全读取。")
            val text = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(text)
            if (root.optString("format") != "invoice_manager_project_share") {
                throw IllegalArgumentException("这不是发票小管家合作版生成的项目分享包。")
            }
            if (root.optInt("formatVersion", 0) != 1) throw IllegalArgumentException("分享包版本不兼容，请让成员使用最新版合作版重新导出。")
            val projectName = root.optString("projectName", "成员项目").trim().ifBlank { "成员项目" }
            val categories = mutableListOf<String>()
            val categoryArray = root.optJSONArray("categories") ?: JSONArray()
            for (i in 0 until categoryArray.length()) {
                val category = categoryArray.optString(i).trim()
                if (category.isNotEmpty() && !categories.contains(category)) categories.add(category)
            }
            val invoiceArray = root.optJSONArray("invoices") ?: JSONArray()
            if (invoiceArray.length() > 5000) throw IllegalArgumentException("这个分享包包含的发票数量异常，已停止导入。")
            val invoices = mutableListOf<PackageInvoice>()
            var totalDeclaredBytes = 0L
            for (i in 0 until invoiceArray.length()) {
                val item = invoiceArray.optJSONObject(i) ?: continue
                val archivePath = item.optString("file")
                if (!archivePath.startsWith("files/") || archivePath.contains("..") || archivePath.startsWith("/")) {
                    throw IllegalArgumentException("分享包内文件路径不安全，已停止导入。")
                }
                val name = item.optString("name", "发票_${i + 1}").ifBlank { "发票_${i + 1}" }
                val category = item.optString("category", "其他").ifBlank { "其他" }
                if (!categories.contains(category)) categories.add(category)
                val archivedFile = zip.getEntry(archivePath) ?: throw IllegalArgumentException("分享包缺少文件：$name")
                if (archivedFile.isDirectory || archivedFile.size > 512L * 1024L * 1024L) throw IllegalArgumentException("文件大小异常：$name")
                if (archivedFile.size > 0) totalDeclaredBytes += archivedFile.size
                if (totalDeclaredBytes > 1024L * 1024L * 1024L) throw IllegalArgumentException("分享包总体积超过 1 GB，请拆分项目后再分享。")
                invoices.add(PackageInvoice(name, category, item.optBoolean("isPdf", name.lowercase(Locale.ROOT).endsWith(".pdf")), item.optString("note", ""), archivePath))
            }
            if (invoices.isEmpty()) throw IllegalArgumentException("分享包里没有可导入的发票。")
            return ProjectSharePackage(projectName, categories, invoices)
        }
    }

    private fun handleLoadedProjectPackage(zipFile: File, pack: ProjectSharePackage, requestedTargetId: String?) {
        if (requestedTargetId != null) {
            val target = projects.firstOrNull { it.id == requestedTargetId }
            if (target == null) {
                zipFile.delete()
                Toast.makeText(this, "原目标项目已不存在，请从项目首页重新导入。", Toast.LENGTH_LONG).show()
                return
            }
            confirmProjectPackageImport(zipFile, pack, target, false)
            return
        }
        val choices = mutableListOf<String>()
        choices.add("新建项目：${pack.projectName}")
        projects.forEach { choices.add("合并到：${it.name}（现有 ${it.invoices.size} 张发票）") }
        AlertDialog.Builder(this)
            .setTitle("选择导入目标项目")
            .setItems(choices.toTypedArray()) { _, which ->
                if (which == 0) confirmProjectPackageImport(zipFile, pack, null, true)
                else confirmProjectPackageImport(zipFile, pack, projects[which - 1], false)
            }
            .setOnCancelListener { zipFile.delete() }
            .show()
    }

    private fun confirmProjectPackageImport(zipFile: File, pack: ProjectSharePackage, target: Project?, makeNewProject: Boolean) {
        val targetName = target?.name ?: pack.projectName
        val message = "分享包：${pack.projectName}\n发票文件：${pack.invoices.size} 张\n分类：${pack.categories.size} 个\n\n将把图片 / PDF、分类和每张发票的备注导入“$targetName”。现有内容不会被覆盖；完全相同的文件记录会跳过。未打款、未开发票台账不包含在分享包中。"
        AlertDialog.Builder(this)
            .setTitle(if (makeNewProject) "新建项目并导入" else "确认导入成员项目")
            .setMessage(message)
            .setNegativeButton("取消") { _, _ -> zipFile.delete() }
            .setPositiveButton("确认导入") { _, _ ->
                Toast.makeText(this, "正在导入发票文件，请稍候…", Toast.LENGTH_SHORT).show()
                Thread {
                    try {
                        val outcome = performProjectPackageImport(zipFile, pack, target, makeNewProject)
                        runOnUiThread {
                            if (outcome.isNewProject) projects.add(outcome.project)
                            outcome.categoriesToAdd.forEach { if (!outcome.project.categories.contains(it)) outcome.project.categories.add(it) }
                            outcome.project.invoices.addAll(outcome.addedInvoices)
                            persistState()
                            zipFile.delete()
                            activeProjectId = outcome.project.id
                            selectedIds.clear()
                            subScreen = null
                            buildDetailUi()
                            val messageText = "导入完成：新增 ${outcome.addedInvoices.size} 张，跳过重复 ${outcome.skippedDuplicates} 张，失败 ${outcome.failedFiles} 张。"
                            AlertDialog.Builder(this)
                                .setTitle("项目导入完成")
                                .setMessage("项目：${outcome.project.name}\n$messageText")
                                .setPositiveButton("确定", null)
                                .show()
                        }
                    } catch (e: Exception) {
                        zipFile.delete()
                        runOnUiThread {
                            AlertDialog.Builder(this)
                                .setTitle("导入失败")
                                .setMessage(e.message ?: "发生未知错误，请重新选择分享包。")
                                .setPositiveButton("确定", null)
                                .show()
                        }
                    }
                }.start()
            }
            .show()
    }

    private fun performProjectPackageImport(
        zipFile: File,
        pack: ProjectSharePackage,
        existingTarget: Project?,
        makeNewProject: Boolean
    ): PackageImportOutcome {
        val newProject = if (makeNewProject || existingTarget == null) {
            var name = pack.projectName
            if (projects.any { it.name.equals(name, ignoreCase = true) }) name = "$name（成员导入）"
            Project(UUID.randomUUID().toString(), name, pack.categories.toMutableList().ifEmpty { defaultCategories() })
        } else existingTarget
        val directory = File(filesDir, "projectFiles/${newProject.id}").apply { mkdirs() }
        val newInvoices = mutableListOf<Invoice>()
        val categoriesToAdd = pack.categories.filter { !newProject.categories.contains(it) }
        val existingKeys = mutableSetOf<String>()
        newProject.invoices.forEach { invoice ->
            val existingFile = invoice.localPath?.let { File(it) }
            if (existingFile != null && existingFile.isFile) {
                val hash = sha256(existingFile)
                existingKeys.add(duplicateKey(hash, invoice.name, invoice.category, invoice.note))
            }
        }
        var skipped = 0
        var failed = 0
        ZipFile(zipFile).use { zip ->
            pack.invoices.forEach { item ->
                try {
                    val entry = zip.getEntry(item.archivePath) ?: throw IllegalArgumentException("缺少文件：${item.name}")
                    if (entry.isDirectory || (entry.size > 0 && entry.size > 1024L * 1024L * 1024L)) throw IllegalArgumentException("文件大小异常：${item.name}")
                    val temp = File(directory, ".incoming_${UUID.randomUUID()}.tmp")
                    zip.getInputStream(entry).use { source -> FileOutputStream(temp).use { dest -> source.copyTo(dest) } }
                    val hash = sha256(temp)
                    val key = duplicateKey(hash, item.name, item.category, item.note)
                    if (existingKeys.contains(key)) {
                        temp.delete()
                        skipped++
                    } else {
                        val finalFile = File(directory, "${UUID.randomUUID()}.${safeExtension(item.name, item.isPdf)}")
                        if (!temp.renameTo(finalFile)) {
                            FileInputStream(temp).use { input -> FileOutputStream(finalFile).use { output -> input.copyTo(output) } }
                            temp.delete()
                        }
                        newInvoices.add(Invoice(UUID.randomUUID().toString(), item.name, item.category, item.isPdf, finalFile.absolutePath, null, item.note))
                        existingKeys.add(key)
                    }
                } catch (_: Exception) {
                    failed++
                }
            }
        }
        if (newInvoices.isEmpty() && makeNewProject) deleteRecursively(directory)
        if (newInvoices.isEmpty() && failed > 0) throw IllegalStateException("没有成功导入任何发票文件。请让成员重新生成项目分享包后再试。")
        return PackageImportOutcome(newProject, makeNewProject || existingTarget == null, newInvoices, categoriesToAdd, skipped, failed)
    }

    private fun duplicateKey(hash: String, name: String, category: String, note: String): String =
        "$hash|${name.trim()}|${category.trim()}|${note.trim()}"

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(16 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun persistState() {
        try {
            val array = JSONArray()
            projects.forEach { project ->
                val categoryArray = JSONArray()
                project.categories.forEach { categoryArray.put(it) }
                val invoicesArray = JSONArray()
                project.invoices.forEach { invoice ->
                    invoicesArray.put(JSONObject()
                        .put("id", invoice.id)
                        .put("name", invoice.name)
                        .put("category", invoice.category)
                        .put("isPdf", invoice.isPdf)
                        .put("localPath", invoice.localPath)
                        .put("originalUri", invoice.originalUri)
                        .put("note", invoice.note))
                }
                val peopleArray = JSONArray()
                project.paymentPeople.forEach { person ->
                    val expensesArray = JSONArray()
                    person.expenses.forEach { expense ->
                        expensesArray.put(JSONObject()
                            .put("id", expense.id)
                            .put("date", expense.date)
                            .put("description", expense.description)
                            .put("amount", expense.amount)
                            .put("hasInvoice", expense.hasInvoice))
                    }
                    peopleArray.put(JSONObject()
                        .put("id", person.id)
                        .put("name", person.name)
                        .put("paid", person.paid)
                        .put("expenses", expensesArray))
                }
                val uninvoicedArray = JSONArray()
                project.uninvoicedRecords.forEach { record ->
                    uninvoicedArray.put(JSONObject()
                        .put("id", record.id)
                        .put("date", record.date)
                        .put("description", record.description)
                        .put("amount", record.amount))
                }
                array.put(JSONObject()
                    .put("id", project.id)
                    .put("name", project.name)
                    .put("categories", categoryArray)
                    .put("invoices", invoicesArray)
                    .put("paymentPeople", peopleArray)
                    .put("uninvoicedRecords", uninvoicedArray))
            }
            getSharedPreferences("invoice_manager", MODE_PRIVATE).edit().putString("projects_v2", array.toString()).apply()
        } catch (_: Exception) {
            Toast.makeText(this, "保存项目记录失败，请稍后重试", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadState() {
        val prefs = getSharedPreferences("invoice_manager", MODE_PRIVATE)
        try {
            val raw = prefs.getString("projects_v2", null)
            if (!raw.isNullOrBlank()) {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val categoryList = mutableListOf<String>()
                    val ca = obj.optJSONArray("categories") ?: JSONArray()
                    for (c in 0 until ca.length()) categoryList.add(ca.getString(c))
                    if (categoryList.isEmpty()) categoryList.addAll(defaultCategories())
                    val project = Project(obj.getString("id"), obj.getString("name"), categoryList)
                    val invoicesArray = obj.optJSONArray("invoices") ?: JSONArray()
                    for (j in 0 until invoicesArray.length()) {
                        val invoice = invoicesArray.getJSONObject(j)
                        project.invoices.add(Invoice(
                            invoice.optString("id", UUID.randomUUID().toString()),
                            invoice.getString("name"),
                            invoice.optString("category", "其他"),
                            invoice.optBoolean("isPdf", false),
                            invoice.optString("localPath").takeIf { it.isNotBlank() && it != "null" },
                            invoice.optString("originalUri").takeIf { it.isNotBlank() && it != "null" },
                            invoice.optString("note", "")
                        ))
                    }
                    val peopleArray = obj.optJSONArray("paymentPeople") ?: JSONArray()
                    for (personIndex in 0 until peopleArray.length()) {
                        val personObj = peopleArray.getJSONObject(personIndex)
                        val person = PaymentPerson(
                            personObj.optString("id", UUID.randomUUID().toString()),
                            personObj.optString("name", "未命名"),
                            personObj.optBoolean("paid", false)
                        )
                        val expenses = personObj.optJSONArray("expenses") ?: JSONArray()
                        for (expenseIndex in 0 until expenses.length()) {
                            val expenseObj = expenses.getJSONObject(expenseIndex)
                            person.expenses.add(ExpenseItem(
                                expenseObj.optString("id", UUID.randomUUID().toString()),
                                expenseObj.optString("date", ""),
                                expenseObj.optString("description", ""),
                                expenseObj.optDouble("amount", 0.0),
                                expenseObj.optBoolean("hasInvoice", false)
                            ))
                        }
                        project.paymentPeople.add(person)
                    }
                    val uninvoicedArray = obj.optJSONArray("uninvoicedRecords") ?: JSONArray()
                    for (recordIndex in 0 until uninvoicedArray.length()) {
                        val recordObj = uninvoicedArray.getJSONObject(recordIndex)
                        project.uninvoicedRecords.add(UninvoicedRecord(
                            recordObj.optString("id", UUID.randomUUID().toString()),
                            recordObj.optString("date", ""),
                            recordObj.optString("description", ""),
                            recordObj.optDouble("amount", 0.0)
                        ))
                    }
                    projects.add(project)
                }
            } else {
                migrateLegacyState(prefs)
            }
        } catch (_: Exception) {
            projects.clear()
            migrateLegacyState(prefs)
        }
    }

    private fun migrateLegacyState(prefs: android.content.SharedPreferences) {
        try {
            val oldInvoices = prefs.getString("invoices", null) ?: return
            val array = JSONArray(oldInvoices)
            if (array.length() == 0) return
            val categories = mutableListOf<String>()
            prefs.getString("categories", null)?.let { raw ->
                val categoryArray = JSONArray(raw)
                for (i in 0 until categoryArray.length()) categories.add(categoryArray.getString(i))
            }
            if (categories.isEmpty()) categories.addAll(defaultCategories())
            val project = Project(UUID.randomUUID().toString(), "默认项目", categories)
            for (i in 0 until array.length()) {
                val old = array.getJSONObject(i)
                val uriString = old.optString("uri")
                val name = old.optString("name", "发票_${i + 1}")
                val uri = Uri.parse(uriString)
                val isPdf = old.optBoolean("isPdf", name.lowercase(Locale.ROOT).endsWith(".pdf"))
                val copy = try { copyUriIntoProject(uri, project, name, isPdf) } catch (_: Exception) { null }
                project.invoices.add(Invoice(UUID.randomUUID().toString(), name, old.optString("category", "其他"), isPdf, copy?.absolutePath, uriString))
            }
            projects.add(project)
            persistState()
        } catch (_: Exception) { }
    }

    private fun deleteRecursively(file: File) {
        if (file.isDirectory) file.listFiles()?.forEach { deleteRecursively(it) }
        file.delete()
    }

    private fun cardContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(white, 20, Color.rgb(239, 242, 238), 1)
    }

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false,
        maxLines: Int = Int.MAX_VALUE
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        this.maxLines = maxLines
        if (maxLines < Int.MAX_VALUE) ellipsize = android.text.TextUtils.TruncateAt.END
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun actionButton(
        title: String,
        backgroundColor: Int,
        textColor: Int,
        textSize: Float = 14f,
        action: () -> Unit
    ): Button = Button(this).apply {
        text = title
        this.textSize = textSize
        isAllCaps = false
        setTextColor(textColor)
        background = rounded(backgroundColor, 14)
        stateListAnimator = null
        setPadding(dp(10), dp(5), dp(10), dp(5))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int = color, strokeWidth: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (strokeWidth > 0) setStroke(dp(strokeWidth), strokeColor)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private fun defaultCategories() = mutableListOf("办公", "交通", "住宿", "餐饮", "设备", "其他")
    }
}
